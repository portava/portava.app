/**
 * Admin — Stamp Studio failed generation jobs.
 * Lists queue jobs stuck in retryable_failed or permanently_failed (jobs that
 * exhausted their auto-requeue rounds) and lets an admin re-queue them
 * (resets status → queued, attempts → 0, auto-requeue counter → 0).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { router } from 'expo-router';
import { ArrowLeft, RefreshCw, TriangleAlert, XCircle } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRequireAdmin } from '../../../src/hooks/useRequireAdmin';
import { color, space, radius, type as t } from '../../../src/theme/tokens';
import {
  getAdminStampQueue,
  requeueFailedJob,
  clearCleanupError,
  type GenerationQueueJob,
} from '../../../src/services/adminStamps';

export default function FailedJobsScreen() {
  const insets = useSafeAreaInsets();
  useRequireAdmin();

  const [jobs, setJobs]             = useState<GenerationQueueJob[]>([]);
  const [loading, setLoading]       = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId]         = useState<string | null>(null);
  const [clearingId, setClearingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await getAdminStampQueue({ status: 'retryable_failed,permanently_failed', limit: 100 });
    if (res.ok) setJobs(res.data.jobs ?? []);
    setLoading(false);
    setRefreshing(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const onRefresh = useCallback(() => { setRefreshing(true); load(); }, [load]);

  const onMarkCleaned = useCallback((job: GenerationQueueJob) => {
    const name = job.universal_stamp_catalog?.display_name ?? job.catalog_id;
    Alert.alert(
      'Mark files as cleaned?',
      `Confirm you have manually removed the orphaned files for "${name}" from the stamp-artwork bucket. The warning badge will be dismissed.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Mark cleaned',
          onPress: async () => {
            setClearingId(job.id);
            const res = await clearCleanupError(job.id);
            setClearingId(null);
            if (res.ok) {
              setJobs((prev) =>
                prev.map((j) =>
                  j.id === job.id
                    ? { ...j, cleanup_error: null, cleanup_error_paths: null }
                    : j
                )
              );
            } else {
              Alert.alert('Error', (res as any).error ?? 'Failed to clear cleanup error');
            }
          },
        },
      ],
    );
  }, []);

  const onRequeue = useCallback((job: GenerationQueueJob) => {
    const name = job.universal_stamp_catalog?.display_name ?? job.catalog_id;
    Alert.alert(
      'Re-queue job?',
      `Artwork generation for "${name}" will be retried from scratch (attempts reset to 0).`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Re-queue',
          onPress: async () => {
            setBusyId(job.id);
            const res = await requeueFailedJob(job.id);
            setBusyId(null);
            if (res.ok) {
              setJobs((prev) => prev.filter((j) => j.id !== job.id));
            } else {
              Alert.alert('Error', (res as any).error ?? 'Failed to re-queue job');
            }
          },
        },
      ],
    );
  }, []);

  const renderJob = ({ item }: { item: GenerationQueueJob }) => {
    const cat = item.universal_stamp_catalog;
    const isPermanent = item.status === 'permanently_failed';
    return (
      <View style={styles.row}>
        <View style={styles.rowMeta}>
          <View style={styles.rowNameLine}>
            <Text style={styles.rowName} numberOfLines={1}>
              {cat?.display_name ?? item.catalog_id}
            </Text>
            {isPermanent ? (
              <View style={styles.permBadge}>
                <Text style={styles.permBadgeText}>Permanently failed</Text>
              </View>
            ) : null}
          </View>
          {cat ? (
            <Text style={styles.rowSub}>{cat.stamp_type} · {cat.country_code}</Text>
          ) : null}
          <Text style={styles.rowSub}>
            {item.attempts}/{item.max_attempts} attempts · failed {new Date(item.updated_at).toLocaleString()}
          </Text>
          {item.last_error ? (
            <Text style={styles.rowError} numberOfLines={2}>{item.last_error}</Text>
          ) : null}
          {item.cleanup_error ? (
            <View style={styles.cleanupBadge} testID="row-cleanup-badge" accessibilityRole="alert" accessibilityLiveRegion="assertive">
              <TriangleAlert size={11} color="#92400E" strokeWidth={2} />
              <Text style={styles.cleanupBadgeTitle}>
                {item.cleanup_error_paths && item.cleanup_error_paths.length > 0
                  ? `${item.cleanup_error_paths.length} orphaned file${item.cleanup_error_paths.length !== 1 ? 's' : ''} need manual removal`
                  : 'Orphaned storage files need manual removal'}
              </Text>
            </View>
          ) : null}
          {item.cleanup_error_paths && item.cleanup_error_paths.length > 0 ? (
            <Text style={styles.cleanupPaths} numberOfLines={3}>
              {item.cleanup_error_paths.join('\n')}
            </Text>
          ) : null}
          {item.cleanup_error ? (
            <Text style={styles.cleanupError} numberOfLines={2}>{item.cleanup_error}</Text>
          ) : null}
        </View>
        <View style={styles.actions}>
          {item.cleanup_error ? (
            <Pressable
              style={styles.cleanedBtn}
              onPress={() => onMarkCleaned(item)}
              disabled={clearingId === item.id}
            >
              {clearingId === item.id ? (
                <ActivityIndicator size="small" color="#92400E" />
              ) : (
                <Text style={styles.cleanedText}>Mark cleaned</Text>
              )}
            </Pressable>
          ) : null}
          <Pressable
            style={styles.requeueBtn}
            onPress={() => onRequeue(item)}
            disabled={busyId === item.id}
          >
            {busyId === item.id ? (
              <ActivityIndicator size="small" color={color.onInk} />
            ) : (
              <>
                <RefreshCw size={14} color={color.onInk} strokeWidth={2} />
                <Text style={styles.requeueText}>Re-queue</Text>
              </>
            )}
          </Pressable>
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={8} style={styles.backBtn}>
          <ArrowLeft size={22} color={color.ink} />
        </Pressable>
        <Text style={styles.title}>Failed Generation Jobs</Text>
        <Text style={styles.count}>{jobs.length}</Text>
      </View>

      {loading ? (
        <View style={styles.center}><ActivityIndicator color={color.ink} /></View>
      ) : (
        <FlatList
          testID="failed-jobs-list"
          data={jobs}
          keyExtractor={(item) => item.id}
          renderItem={renderJob}
          contentContainerStyle={{ paddingBottom: insets.bottom + space.xl }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <XCircle size={28} color={color.mute} strokeWidth={1.5} />
              <Text style={styles.empty}>No failed generation jobs</Text>
            </View>
          }
          ItemSeparatorComponent={() => <View style={styles.sep} />}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root:        { flex: 1, backgroundColor: color.paper },
  header:      { flexDirection: 'row', alignItems: 'center', paddingHorizontal: space.md, paddingVertical: space.sm, borderBottomWidth: 1, borderBottomColor: color.haze },
  backBtn:     { marginRight: space.sm },
  title:       { ...t.heading, color: color.ink, flex: 1 },
  count:       { ...t.small, color: color.mute },
  center:      { flex: 1, justifyContent: 'center', alignItems: 'center' },
  row:         { flexDirection: 'row', alignItems: 'center', paddingHorizontal: space.md, paddingVertical: space.md, gap: space.sm },
  rowMeta:     { flex: 1 },
  rowNameLine: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  rowName:     { ...t.body, color: color.ink, fontWeight: '600', flexShrink: 1 },
  permBadge:   { backgroundColor: '#FEE2E2', borderRadius: radius.pill, paddingHorizontal: 8, paddingVertical: 2 },
  permBadgeText: { fontSize: 10, fontWeight: '700', color: '#B91C1C' },
  rowSub:      { ...t.small, color: color.mute },
  rowError:    { ...t.small, color: '#DC2626', marginTop: 2 },
  actions:          { flexDirection: 'column', alignItems: 'flex-end', gap: 6 },
  requeueBtn:       { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: color.ink, borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 8 },
  requeueText:      { fontSize: 12, fontWeight: '700', color: color.onInk },
  cleanedBtn:       { borderWidth: 1, borderColor: '#D97706', borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 6 },
  cleanedText:      { fontSize: 12, fontWeight: '700', color: '#92400E' },
  sep:              { height: 1, backgroundColor: color.haze, marginLeft: space.md },
  emptyWrap:        { alignItems: 'center', gap: space.xs, padding: space.xl },
  empty:            { color: color.mute },
  cleanupBadge:     { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#FEF3C7', borderRadius: radius.pill, paddingHorizontal: 8, paddingVertical: 3, marginTop: 4, alignSelf: 'flex-start' },
  cleanupBadgeTitle: { fontSize: 10, fontWeight: '700', color: '#92400E' },
  cleanupPaths:     { ...t.small, color: '#78350F', fontFamily: 'monospace', marginTop: 2, fontSize: 10 },
  cleanupError:     { ...t.small, color: '#D97706', marginTop: 1 },
});
