import React, { useState, useCallback, useRef } from 'react';
import { View, Text, ScrollView, Pressable, ActivityIndicator, StyleSheet } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Share2, Users, Clock } from 'lucide-react-native';
import { getPendingPosts } from '../../src/services/posts';
import { useRentABuddyFlag } from '../../src/hooks/useRentABuddyFlag';
import { usePassport } from '../../src/hooks/usePassport';
import { usePostcardActions } from '../../src/hooks/usePostcardActions';
import { NotificationBell } from '../../src/components/NotificationBell';
import { usePassportShare } from '../../src/hooks/usePassportShare';
import { useHighlightRingState, invalidateHighlightCache } from '../../src/hooks/useHighlightRingState';
import { HighlightViewer } from '../../src/components/HighlightViewer';
import { HighlightComposer } from '../../src/components/HighlightComposer';
import { MemoriesTab } from '../../src/components/MemoriesTab';
import { SuggestedMemoryModal } from '../../src/components/SuggestedMemoryModal';
import type { PassportMemory } from '../../src/services/passportStamps';
import { useSession } from '../../src/context/SessionContext';
import { listMyTrips } from '../../src/services/trips';
import { PassportHero } from '../../src/components/PassportHero';
import { CompactStatsRow } from '../../src/components/CompactStatsRow';
import { PostcardsTab } from '../../src/components/PostcardsTab';
import { StampsTab } from '../../src/components/StampsTab';
import { TripsTab } from '../../src/components/TripsTab';
import { MapTab } from '../../src/components/MapTab';
import { AboutTab } from '../../src/components/AboutTab';
import { PassportSettingsSheet } from '../../src/components/PassportSettingsSheet';
import { OwnerActionMenu } from '../../src/components/OwnerActionMenu';
import { ProfileCompletionCard } from '../../src/components/ProfileCompletionCard';
import { PassportShareCard } from '../../src/components/PassportShareCard';
import type { OwnProfile, PassportPostcard } from '../../src/types/models';
import type { TripRow } from '../../src/services/trips';
import { color, space, radius, type as t } from '../../src/theme/tokens';
import { CompassStatusCard } from '../../src/components/compass/CompassStatusCard';

type Tab = 'postcards' | 'stamps' | 'memories' | 'trips' | 'map' | 'about';
const TABS: { key: Tab; label: string }[] = [
  { key: 'postcards', label: 'Postcards' },
  { key: 'stamps', label: 'Stamps' },
  { key: 'memories', label: 'Memories' },
  { key: 'trips', label: 'Trips' },
  { key: 'map', label: 'Map' },
  { key: 'about', label: 'About' },
];

export default function PassportScreen() {
  const { profile, postcards, stamps, memories, suggestions, loading, error, reload } = usePassport();
  const { userId: ownUserId } = useSession();
  const { enabled: rentBuddyEnabled } = useRentABuddyFlag();
  const [tab, setTab] = useState<Tab>('postcards');
  const [menuOpen, setMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsSection, setSettingsSection] = useState<'profile' | 'passport' | 'preferences' | 'safety'>('profile');
  const [trips, setTrips] = useState<TripRow[]>([]);
  const [tripsLoaded, setTripsLoaded] = useState(false);
  const insets = useSafeAreaInsets();

  // Suggestion modal — show the first pending suggestion automatically once per session
  const [activeSuggestion, setActiveSuggestion] = useState<PassportMemory | null>(null);
  const suggestionShownRef = React.useRef(false);
  React.useEffect(() => {
    if (!suggestionShownRef.current && suggestions.length > 0) {
      suggestionShownRef.current = true;
      setActiveSuggestion(suggestions[0]);
    }
  }, [suggestions]);

  // Own highlight ring state — refreshKey forces an immediate cache-bust + re-fetch
  // after a new highlight is created so the ring activates without waiting for TTL.
  const [highlightRefreshKey, setHighlightRefreshKey] = useState(0);
  const ownRingState = useHighlightRingState(ownUserId, highlightRefreshKey);
  const hasOwnHighlights = ownRingState?.hasActive ?? false;
  const allOwnHighlightsViewed = ownRingState?.allViewed ?? false;
  const [highlightViewerOpen, setHighlightViewerOpen] = useState(false);
  const [highlightComposerOpen, setHighlightComposerOpen] = useState(false);

  // Tracks whether the composer was triggered from inside the viewer (vs. ring/camera)
  const composerFromViewer = useRef(false);

  // Ring press: view existing highlights or open composer to create a new one
  const handleOwnRingPress = useCallback(() => {
    if (hasOwnHighlights) setHighlightViewerOpen(true);
    else setHighlightComposerOpen(true);
  }, [hasOwnHighlights]);

  // Camera button: always opens the composer directly (for adding a new highlight)
  const handleNewHighlightPress = useCallback(() => {
    composerFromViewer.current = false;
    setHighlightComposerOpen(true);
  }, []);

  // "+" button inside the viewer: close viewer, open composer, then return to viewer
  const handleAddHighlightFromViewer = useCallback(() => {
    composerFromViewer.current = true;
    setHighlightViewerOpen(false);
    setHighlightComposerOpen(true);
  }, []);

  // On successful highlight creation: bust the cache and trigger immediate ring refresh
  const handleHighlightSuccess = useCallback(() => {
    if (ownUserId) invalidateHighlightCache(ownUserId);
    setHighlightRefreshKey((k) => k + 1);
    setHighlightComposerOpen(false);
    if (composerFromViewer.current) {
      composerFromViewer.current = false;
      setHighlightViewerOpen(true);
    }
  }, [ownUserId]);

  // On highlight deleted: re-fetch ring state so the ring de-activates immediately
  // if no highlights remain, without waiting for the 60-second cache TTL.
  const handleHighlightDeleted = useCallback(() => {
    setHighlightRefreshKey((k) => k + 1);
  }, []);

  const [localPostcards, setLocalPostcards] = useState<PassportPostcard[]>([]);

  React.useEffect(() => {
    setLocalPostcards(postcards);
  }, [postcards]);

  React.useEffect(() => {
    if (tab === 'trips' && !tripsLoaded) {
      setTripsLoaded(true);
      listMyTrips().then(setTrips).catch(() => {});
    }
  }, [tab, tripsLoaded]);

  const actions = usePostcardActions(setLocalPostcards);

  const openSettings = useCallback((section: typeof settingsSection = 'profile') => {
    setSettingsSection(section);
    setSettingsOpen(true);
  }, []);

  const handleSaved = useCallback((_updated: OwnProfile) => {
    reload();
  }, [reload]);

  const handleEditProfile = useCallback(() => {
    router.push('/profile/edit' as any);
  }, []);

  const handleViewAsPublic = useCallback(() => {
    const username = profile?.username;
    if (username) router.push(`/u/${username}` as any);
  }, [profile]);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={color.signal} />
      </View>
    );
  }

  if (error || !profile) {
    return (
      <View style={[styles.center, { paddingTop: insets.top + 32, paddingHorizontal: space.xl, gap: space.lg }]}>
        <Text style={{ ...t.heading, color: color.ink, textAlign: 'center' }}>
          {error ? 'Could not load your passport' : 'Sign in to view your passport'}
        </Text>
        <Text style={{ ...t.body, color: color.mute, textAlign: 'center' }}>
          {error
            ? 'Check your connection and try again.'
            : 'Your travel passport, stamps, and memories live here once you sign in.'}
        </Text>
        {error ? (
          <Pressable
            style={{ backgroundColor: color.signal, paddingHorizontal: space.xl, paddingVertical: 12, borderRadius: radius.md }}
            onPress={reload}
          >
            <Text style={{ ...t.bodyStrong, color: '#fff' }}>Retry</Text>
          </Pressable>
        ) : (
          <Pressable
            style={{ backgroundColor: color.signal, paddingHorizontal: space.xl, paddingVertical: 12, borderRadius: radius.md }}
            onPress={() => router.push('/sign-in')}
          >
            <Text style={{ ...t.bodyStrong, color: '#fff' }}>Sign in</Text>
          </Pressable>
        )}
      </View>
    );
  }

  const handleSuggestionAccepted = (id: string) => {
    setActiveSuggestion(null);
    reload();
  };

  const handleSuggestionDismissed = (id: string) => {
    setActiveSuggestion(null);
  };

  return (
    <View style={{ flex: 1 }}>
      <PassportContent
        profile={profile}
        postcards={localPostcards}
        stamps={stamps}
        memories={memories}
        trips={trips}
        tab={tab}
        setTab={setTab}
        menuOpen={menuOpen}
        setMenuOpen={setMenuOpen}
        settingsOpen={settingsOpen}
        setSettingsOpen={setSettingsOpen}
        settingsSection={settingsSection}
        openSettings={openSettings}
        actions={actions}
        handleSaved={handleSaved}
        handleEditProfile={handleEditProfile}
        handleViewAsPublic={handleViewAsPublic}
        reload={reload}
        insets={insets}
        hasHighlights={hasOwnHighlights}
        allHighlightsViewed={allOwnHighlightsViewed}
        onHighlightRingPress={handleOwnRingPress}
        onNewHighlightPress={handleNewHighlightPress}
        rentBuddyEnabled={rentBuddyEnabled}
      />
      <HighlightViewer
        visible={highlightViewerOpen}
        highlights={ownRingState?.highlights ?? []}
        currentUserId={ownUserId ?? undefined}
        onClose={() => setHighlightViewerOpen(false)}
        onAddHighlight={handleAddHighlightFromViewer}
        onDeleted={handleHighlightDeleted}
      />
      <HighlightComposer
        visible={highlightComposerOpen}
        onClose={() => setHighlightComposerOpen(false)}
        onSuccess={handleHighlightSuccess}
      />
      <SuggestedMemoryModal
        suggestion={activeSuggestion}
        visible={activeSuggestion !== null}
        onClose={() => setActiveSuggestion(null)}
        onAccepted={handleSuggestionAccepted}
        onDismissed={handleSuggestionDismissed}
      />
    </View>
  );
}

function PassportContent({
  profile, postcards, stamps, memories, trips, tab, setTab,
  menuOpen, setMenuOpen, settingsOpen, setSettingsOpen,
  settingsSection, openSettings, actions, handleSaved, handleEditProfile, handleViewAsPublic, reload, insets,
  hasHighlights, allHighlightsViewed, onHighlightRingPress, onNewHighlightPress, rentBuddyEnabled,
}: {
  profile: OwnProfile;
  postcards: PassportPostcard[];
  stamps: import('../../src/types/models').PassportStamp[];
  memories: PassportMemory[];
  trips: TripRow[];
  tab: Tab;
  setTab: (t: Tab) => void;
  menuOpen: boolean;
  setMenuOpen: (v: boolean) => void;
  settingsOpen: boolean;
  setSettingsOpen: (v: boolean) => void;
  settingsSection: 'profile' | 'passport' | 'preferences' | 'safety';
  openSettings: (s?: 'profile' | 'passport' | 'preferences' | 'safety') => void;
  actions: ReturnType<typeof usePostcardActions>;
  handleSaved: (p: OwnProfile) => void;
  handleEditProfile: () => void;
  handleViewAsPublic: () => void;
  reload: () => void;
  insets: { top: number; bottom: number };
  hasHighlights?: boolean;
  allHighlightsViewed?: boolean;
  onHighlightRingPress?: () => void;
  onNewHighlightPress?: () => void;
  rentBuddyEnabled?: boolean;
}) {
  const verifiedStamps = stamps.filter((s) => !s.locked).length;
  const { cardRef, share, sharing } = usePassportShare(profile.username ?? null);
  const [pendingCount, setPendingCount] = useState(0);

  useFocusEffect(useCallback(() => {
    reload();
    getPendingPosts().then((r) => {
      if (r.ok && r.data) setPendingCount(r.data.length);
    }).catch(() => {});
  }, [reload]));

  return (
    <View style={{ flex: 1 }}>
      <ScrollView
        style={{ flex: 1, backgroundColor: color.paper }}
        contentContainerStyle={{ paddingTop: insets.top, paddingBottom: space.xxxl }}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile header */}
        <PassportHero
          profile={profile}
          isOwner
          hasHighlights={hasHighlights}
          allHighlightsViewed={allHighlightsViewed}
          onMenuPress={() => setMenuOpen(true)}
          onAvatarPress={() => openSettings('profile')}
          onHighlightRingPress={onHighlightRingPress}
          onNewHighlightPress={onNewHighlightPress}
        />

        {/* Compact stats row */}
        <CompactStatsRow
          postcards={postcards}
          stamps={verifiedStamps}
          trips={trips}
          onCellPress={(label) => {
            if (label === 'Postcards') setTab('postcards');
            else if (label === 'Stamps') setTab('stamps');
            else if (label === 'Trips') setTab('trips');
            else if (label === 'Countries' || label === 'Cities') setTab('map');
          }}
        />

        {/* Rent a Buddy entry point — flag-gated */}
        {rentBuddyEnabled && (
          <Pressable style={styles.buddyRow} onPress={() => router.push('/(rent-a-buddy)/become' as any)}>
            <View style={[styles.telegraphIcon, { backgroundColor: '#FFF0ED' }]}>
              <Users size={18} color={color.signal} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.telegraphTitle}>Rent a Buddy</Text>
              <Text style={styles.telegraphSub}>Become a local Buddy or find one for your trip</Text>
            </View>
            <Text style={styles.buddyArrow}>→</Text>
          </Pressable>
        )}

        {/* Pending posts entry point — only shown when there are posts waiting */}
        {pendingCount > 0 && (
          <Pressable style={styles.pendingRow} onPress={() => router.push('/pending-posts' as any)}>
            <View style={[styles.telegraphIcon, { backgroundColor: '#8B5CF620' }]}>
              <Clock size={18} color="#8B5CF6" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.telegraphTitle}>Pending posts</Text>
              <Text style={styles.telegraphSub}>Posts waiting to be shared</Text>
            </View>
            <View style={styles.pendingBadge}>
              <Text style={styles.pendingBadgeText}>{pendingCount}</Text>
            </View>
          </Pressable>
        )}

        {/* Profile completion prompt (owner only) */}
        <ProfileCompletionCard
          profile={profile}
          onOpenSettings={() => openSettings('profile')}
        />

        {/* Compass active-user status (owner only, hides itself when opted out) */}
        <CompassStatusCard />

        {/* Tab bar */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.tabBarWrap}
          contentContainerStyle={styles.tabBarContent}
        >
          {TABS.map((tb) => (
            <Pressable
              key={tb.key}
              style={[styles.tab, tab === tb.key && styles.tabActive]}
              onPress={() => setTab(tb.key)}
            >
              <Text style={[styles.tabText, tab === tb.key && styles.tabTextActive]}>
                {tb.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Tab content */}
        <View style={styles.tabContent}>
          {tab === 'postcards' && (
            <PostcardsTab
              postcards={postcards}
              isOwner
              actions={actions}
            />
          )}
          {tab === 'stamps' && <StampsTab stamps={stamps} isOwner />}
          {tab === 'memories' && <MemoriesTab memories={memories} onReload={reload} />}
          {tab === 'trips' && <TripsTab trips={trips} isOwner />}
          {tab === 'map' && <MapTab postcards={postcards} currentCity={profile.currentCity} currentUserId={profile.id} />}
          {tab === 'about' && (
            <AboutTab
              profile={profile}
              isOwner
              onOpenSettings={() => openSettings('preferences')}
            />
          )}
        </View>
      </ScrollView>

      {/* Off-screen share card (captured by usePassportShare) */}
      <View
        style={styles.offScreen}
        pointerEvents="none"
        accessibilityElementsHidden
        importantForAccessibility="no-hide-descendants"
      >
        <PassportShareCard
          ref={cardRef}
          displayName={profile.displayName ?? profile.name ?? null}
          username={profile.username ?? null}
          avatarUrl={profile.avatarUrl ?? null}
          tripCount={trips.length}
          stampCount={verifiedStamps}
          tagline={profile.bio ?? null}
        />
      </View>

      {/* Owner action menu */}
      <OwnerActionMenu
        visible={menuOpen}
        onClose={() => setMenuOpen(false)}
        username={profile.username}
        onEditProfile={() => { setMenuOpen(false); handleEditProfile(); }}
        onSettings={() => openSettings('passport')}
        onViewAsPublic={handleViewAsPublic}
      />

      {/* Settings sheet */}
      {settingsOpen && (
        <PassportSettingsSheet
          visible={settingsOpen}
          profile={profile}
          onClose={() => setSettingsOpen(false)}
          onSaved={handleSaved}
        />
      )}

      {/* Share button — top-right, next to bell */}
      <Pressable
        style={[styles.shareBtn, { top: insets.top + space.sm }]}
        onPress={share}
        disabled={sharing}
        hitSlop={8}
        accessibilityLabel="Share Passport"
      >
        {sharing ? (
          <ActivityIndicator size="small" color={color.ink} />
        ) : (
          <Share2 size={18} color={color.ink} />
        )}
      </Pressable>

      {/* Notifications bell — absolutely positioned top-right, shows popover preview */}
      <NotificationBell style={[styles.bellBtn, { top: insets.top + space.sm }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: color.paper },

  offScreen: {
    position: 'absolute',
    left: -9999,
    top: -9999,
    opacity: 0,
  },

  shareBtn: {
    position: 'absolute',
    right: space.lg + 38 + space.sm,
    zIndex: 20,
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: color.paperRaised,
    borderWidth: 1,
    borderColor: color.haze,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bellBtn: {
    position: 'absolute',
    right: space.lg,
    zIndex: 20,
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: color.paperRaised,
    borderWidth: 1,
    borderColor: color.haze,
    alignItems: 'center',
    justifyContent: 'center',
  },
  telegraphIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: color.signal + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  telegraphTitle: {
    ...t.bodyStrong,
    color: color.ink,
    fontSize: 14,
    fontWeight: '700',
  },
  telegraphSub: {
    ...t.small,
    color: color.mute,
    fontSize: 11,
    marginTop: 1,
  },

  buddyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    marginHorizontal: space.lg,
    marginTop: space.xs,
    marginBottom: space.xs,
    backgroundColor: '#FFF5F5',
    borderWidth: 1,
    borderColor: color.signal + '30',
    borderRadius: 14,
    paddingHorizontal: space.md,
    paddingVertical: 12,
  },
  buddyArrow: { ...t.bodyStrong, color: color.signal, fontSize: 16 },

  pendingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    marginHorizontal: space.lg,
    marginTop: space.xs,
    marginBottom: space.xs,
    backgroundColor: color.paperRaised,
    borderWidth: 1,
    borderColor: '#8B5CF630',
    borderRadius: 14,
    paddingHorizontal: space.md,
    paddingVertical: 12,
  },
  pendingBadge: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: '#8B5CF6',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
  },
  pendingBadgeText: { color: '#fff', fontSize: 11, fontWeight: '700' },

  tabBarWrap: { marginTop: space.md },
  tabBarContent: { paddingHorizontal: space.lg, gap: space.xs },
  tab: {
    paddingHorizontal: space.md, paddingVertical: 8,
    borderRadius: radius.pill, borderWidth: 1, borderColor: color.haze,
    backgroundColor: color.paperRaised,
  },
  tabActive: { backgroundColor: color.ink, borderColor: color.ink },
  tabText: { ...t.small, color: color.mute, fontWeight: '700', fontSize: 13 },
  tabTextActive: { color: color.onInk },

  tabContent: { marginTop: space.md },
});
