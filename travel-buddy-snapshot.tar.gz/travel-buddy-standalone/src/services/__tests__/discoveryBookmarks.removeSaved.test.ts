/**
 * Unit tests for removeSaved — specifically the stale-filter-key cleanup
 * that clears the category filter when the last place is removed.
 *
 * Run via:
 *   node --import tsx/esm --test src/services/__tests__/discoveryBookmarks.removeSaved.test.ts
 *
 * Uses a fake StorageLike so the native AsyncStorage module is never required.
 */
import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { removeSaved, clearAllSaved, toggleSave, _setTestStorage, _setTestToken } from '../discoveryBookmarks.ts';
import { categoryStorageKey } from '../../components/savedPlacesMapFilterStorage.ts';

const GLOBAL_FILTER_KEY = categoryStorageKey('global');
const BOOKMARKS_KEY = 'discovery_bookmarks_v1';

// ── Fake storage factory ───────────────────────────────────────────────────────

interface FakeStorage {
  store: Map<string, string>;
  removedKeys: string[];
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
}

function fakeStorage(initial: Record<string, string> = {}): FakeStorage {
  const store = new Map<string, string>(Object.entries(initial));
  const removedKeys: string[] = [];
  return {
    store,
    removedKeys,
    getItem(key: string): Promise<string | null> {
      return Promise.resolve(store.get(key) ?? null);
    },
    setItem(key: string, value: string): Promise<void> {
      store.set(key, value);
      return Promise.resolve();
    },
    removeItem(key: string): Promise<void> {
      store.delete(key);
      removedKeys.push(key);
      return Promise.resolve();
    },
  };
}

// ── Fixtures ───────────────────────────────────────────────────────────────────

function makePlace(id: string) {
  return { id, name: 'Test Place', category: 'food', type: null, address: null, savedAt: 1000, lat: null, lng: null };
}

function serialise(...ids: string[]): string {
  return JSON.stringify(ids.map(makePlace));
}

// ── Tests ──────────────────────────────────────────────────────────────────────

describe('removeSaved — stale filter key cleanup', () => {
  let storage: FakeStorage;

  beforeEach(() => {
    storage = fakeStorage();
    _setTestStorage(storage);
  });

  it('clears the category filter key when the last place is removed', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    storage.store.set(GLOBAL_FILTER_KEY, 'food');

    await removeSaved('place-1');

    // The bookmarks list should now be empty
    const raw = storage.store.get(BOOKMARKS_KEY);
    assert.equal(raw, '[]');

    // The filter key must have been removed
    assert.ok(
      storage.removedKeys.includes(GLOBAL_FILTER_KEY),
      `expected removeItem(${GLOBAL_FILTER_KEY}) to be called but removedKeys was: ${JSON.stringify(storage.removedKeys)}`,
    );
  });

  it('does NOT clear the filter key when other places remain', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1', 'place-2'));
    storage.store.set(GLOBAL_FILTER_KEY, 'food');

    await removeSaved('place-1');

    // One place remains — filter key must be untouched
    assert.equal(
      storage.removedKeys.filter((k) => k === GLOBAL_FILTER_KEY).length,
      0,
      'removeItem should not be called for the filter key when places remain',
    );
    assert.equal(storage.store.get(GLOBAL_FILTER_KEY), 'food');
  });

  it('clears the filter key even when no filter was previously set', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    // No filter key in storage — removeItem should still be called (idempotent)

    await removeSaved('place-1');

    assert.ok(
      storage.removedKeys.includes(GLOBAL_FILTER_KEY),
      'removeItem should be called for the filter key regardless of whether it existed',
    );
  });

  it('removes the correct place and leaves the rest intact', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1', 'place-2', 'place-3'));

    await removeSaved('place-2');

    const stored = JSON.parse(storage.store.get(BOOKMARKS_KEY) ?? '[]') as Array<{ id: string }>;
    assert.deepEqual(
      stored.map((p) => p.id),
      ['place-1', 'place-3'],
    );
  });

  it('is a no-op for filter cleanup when the id is not in the list', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    storage.store.set(GLOBAL_FILTER_KEY, 'food');

    await removeSaved('nonexistent');

    // place-1 is still there so the list is non-empty — filter must not be cleared
    const stored = JSON.parse(storage.store.get(BOOKMARKS_KEY) ?? '[]') as Array<{ id: string }>;
    assert.equal(stored.length, 1);
    assert.equal(storage.removedKeys.filter((k) => k === GLOBAL_FILTER_KEY).length, 0);
  });

  it('propagates a setItem error and does NOT run the cleanup step', async () => {
    const removedKeys: string[] = [];
    const broken: FakeStorage = {
      store: new Map([[BOOKMARKS_KEY, serialise('place-1')]]),
      removedKeys,
      getItem: (k) => Promise.resolve(broken.store.get(k) ?? null),
      setItem: () => Promise.reject(new Error('disk full')),
      removeItem: (k) => { removedKeys.push(k); return Promise.resolve(); },
    };
    _setTestStorage(broken);

    await assert.rejects(() => removeSaved('place-1'), /disk full/);

    // Cleanup must NOT run — the caller's optimistic rollback owns the failed state
    assert.equal(removedKeys.length, 0);
  });

  it('filter cleanup does not propagate a removeItem rejection', async () => {
    const failing: FakeStorage = {
      store: new Map([[BOOKMARKS_KEY, serialise('place-1')]]),
      removedKeys: [],
      getItem: (k) => Promise.resolve(failing.store.get(k) ?? null),
      setItem: (_k, _v) => Promise.resolve(),
      removeItem: () => Promise.reject(new Error('remove failed')),
    };
    _setTestStorage(failing);

    // The primary removeSaved promise must resolve even if removeItem rejects
    await assert.doesNotReject(() => removeSaved('place-1'));
  });
});

describe('clearAllSaved — bulk-remove with filter key cleanup', () => {
  let storage: FakeStorage;

  beforeEach(() => {
    storage = fakeStorage();
    _setTestStorage(storage);
  });

  it('removes the bookmarks key and the global filter key atomically', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1', 'place-2', 'place-3'));
    storage.store.set(GLOBAL_FILTER_KEY, 'food');

    await clearAllSaved();

    assert.ok(
      storage.removedKeys.includes(BOOKMARKS_KEY),
      'bookmarks key must be removed',
    );
    assert.ok(
      storage.removedKeys.includes(GLOBAL_FILTER_KEY),
      'filter key must be removed',
    );
    assert.equal(storage.store.has(BOOKMARKS_KEY), false);
    assert.equal(storage.store.has(GLOBAL_FILTER_KEY), false);
  });

  it('leaves no stale filter key when called with no filter previously set', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    // No filter key set — removeItem should still be called (idempotent)

    await clearAllSaved();

    assert.ok(
      storage.removedKeys.includes(GLOBAL_FILTER_KEY),
      'removeItem must be called for the filter key even when it was absent',
    );
  });

  it('leaves no stale filter key when called on an already-empty list', async () => {
    // Neither key is in storage — simulates calling clearAll on an empty wishlist
    await clearAllSaved();

    assert.ok(storage.removedKeys.includes(BOOKMARKS_KEY), 'bookmarks key removal must be attempted');
    assert.ok(storage.removedKeys.includes(GLOBAL_FILTER_KEY), 'filter key removal must be attempted');
  });

  it('removes bookmarks key before filter key (bookmarks key is removed first)', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    storage.store.set(GLOBAL_FILTER_KEY, 'parks');

    await clearAllSaved();

    const bookmarksIdx = storage.removedKeys.indexOf(BOOKMARKS_KEY);
    const filterIdx = storage.removedKeys.indexOf(GLOBAL_FILTER_KEY);
    assert.ok(bookmarksIdx !== -1, 'bookmarks key must be removed');
    assert.ok(filterIdx !== -1, 'filter key must be removed');
    assert.ok(bookmarksIdx < filterIdx, 'bookmarks key should be removed before filter key');
  });

  it('propagates a removeItem error on the bookmarks key', async () => {
    const broken: FakeStorage = {
      store: new Map([[BOOKMARKS_KEY, serialise('place-1')]]),
      removedKeys: [],
      getItem: (k) => Promise.resolve(broken.store.get(k) ?? null),
      setItem: (_k, _v) => Promise.resolve(),
      removeItem: () => Promise.reject(new Error('storage error')),
    };
    _setTestStorage(broken);

    await assert.rejects(() => clearAllSaved(), /storage error/);
  });
});

// ── removeSaved — API sync is best-effort, local remove always wins ────────────
//
// removeSaved() writes to AsyncStorage first, then fires a best-effort DELETE
// to Supabase.  The fetch is wrapped in try/catch so a network failure or a
// non-ok response must NEVER revert the local remove or throw to the caller.

describe('removeSaved — API sync is best-effort (local remove is permanent)', () => {
  let storage: FakeStorage;
  let originalFetch: typeof globalThis.fetch;

  beforeEach(() => {
    storage = fakeStorage();
    _setTestStorage(storage);
    _setTestToken('fake-bearer-token'); // exercise the fetch code path
    originalFetch = globalThis.fetch;
  });

  afterEach(() => {
    globalThis.fetch = originalFetch;
    _setTestToken(undefined); // restore real supabase auth for other suites
  });

  it('removes the place from AsyncStorage before the fetch fires', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1', 'place-2'));

    let storageStateAtFetch: Array<{ id: string }> = [];
    (globalThis as { fetch: unknown }).fetch = () => {
      // Capture storage state at the moment fetch is called
      const raw = storage.store.get(BOOKMARKS_KEY) ?? '[]';
      storageStateAtFetch = JSON.parse(raw) as Array<{ id: string }>;
      return Promise.resolve({ ok: true } as Response);
    };

    await removeSaved('place-1');

    assert.equal(
      storageStateAtFetch.length,
      1,
      'AsyncStorage must be updated before the fetch fires',
    );
    assert.equal(
      storageStateAtFetch[0].id,
      'place-2',
      'only the other place should remain when fetch is called',
    );
  });

  it('local entry stays removed when the fetch throws a network error', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1', 'place-2'));
    (globalThis as { fetch: unknown }).fetch = () =>
      Promise.reject(new Error('connection refused'));

    await removeSaved('place-1');

    const stored = JSON.parse(
      storage.store.get(BOOKMARKS_KEY) ?? '[]',
    ) as Array<{ id: string }>;
    assert.equal(stored.length, 1);
    assert.equal(stored[0].id, 'place-2');
    assert.ok(
      !stored.some((p) => p.id === 'place-1'),
      'place-1 must still be absent after a fetch rejection',
    );
  });

  it('does not throw to the caller when the fetch rejects', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    (globalThis as { fetch: unknown }).fetch = () =>
      Promise.reject(new Error('network error'));

    await assert.doesNotReject(
      () => removeSaved('place-1'),
      'removeSaved must resolve even when the Supabase sync fetch rejects',
    );
  });

  it('local entry stays removed when the API returns 404', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1', 'place-2'));
    (globalThis as { fetch: unknown }).fetch = () =>
      Promise.resolve({ ok: false, status: 404 } as Response);

    await removeSaved('place-1');

    const stored = JSON.parse(
      storage.store.get(BOOKMARKS_KEY) ?? '[]',
    ) as Array<{ id: string }>;
    assert.ok(
      !stored.some((p) => p.id === 'place-1'),
      'place-1 must still be absent after a 404 response',
    );
  });

  it('local entry stays removed when the API returns 500', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    (globalThis as { fetch: unknown }).fetch = () =>
      Promise.resolve({ ok: false, status: 500 } as Response);

    await removeSaved('place-1');

    const stored = JSON.parse(
      storage.store.get(BOOKMARKS_KEY) ?? '[]',
    ) as Array<{ id: string }>;
    assert.deepEqual(stored, [], 'place-1 must still be gone after a 500 response');
  });

  it('does not throw to the caller when the API returns a non-ok status', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    (globalThis as { fetch: unknown }).fetch = () =>
      Promise.resolve({ ok: false, status: 503 } as Response);

    await assert.doesNotReject(
      () => removeSaved('place-1'),
      'removeSaved must resolve even when the API returns a non-ok status',
    );
  });

  it('other places are unaffected when only the target entry is removed and sync fails', async () => {
    storage.store.set(BOOKMARKS_KEY, serialise('place-1', 'place-2', 'place-3'));
    (globalThis as { fetch: unknown }).fetch = () =>
      Promise.reject(new Error('server down'));

    await removeSaved('place-2');

    const stored = JSON.parse(
      storage.store.get(BOOKMARKS_KEY) ?? '[]',
    ) as Array<{ id: string }>;
    assert.deepEqual(
      stored.map((p) => p.id),
      ['place-1', 'place-3'],
      'only place-2 should be removed; place-1 and place-3 must be intact',
    );
  });
});

// ── Concurrent toggleSave calls on the same place ─────────────────────────────

describe('toggleSave — concurrent save→unsave race', () => {
  let storage: FakeStorage;

  beforeEach(() => {
    storage = fakeStorage();
    _setTestStorage(storage);
  });

  it('calls removeItem for the filter key at most once when two unsaves race', async () => {
    // Seed one place and the filter key — simulates a user who already saved
    // the place and now rapidly taps unsave twice before the first resolves.
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    storage.store.set(GLOBAL_FILTER_KEY, 'food');

    const place = makePlace('place-1');

    // Fire both toggleSave calls concurrently.  Without the write queue both
    // calls would read the same stale list, both see the place present, and
    // both call removeItem for the filter key — producing a stale filter entry.
    await Promise.all([
      toggleSave(place, 'global'),
      toggleSave(place, 'global'),
    ]);

    const filterKeyRemovals = storage.removedKeys.filter((k) => k === GLOBAL_FILTER_KEY);
    assert.ok(
      filterKeyRemovals.length <= 1,
      `expected removeItem(${GLOBAL_FILTER_KEY}) to be called at most once, ` +
        `but it was called ${filterKeyRemovals.length} times`,
    );
  });

  it('leaves storage in a consistent state after a concurrent save→unsave pair', async () => {
    // Same place saved once already
    storage.store.set(BOOKMARKS_KEY, serialise('place-1'));
    storage.store.set(GLOBAL_FILTER_KEY, 'food');

    const place = makePlace('place-1');

    // Both calls race.  The write queue ensures they execute one after the other,
    // so the net outcome is deterministic: first call removes, second call adds
    // back (or vice-versa).  The invariant is that the storage is coherent —
    // no duplicate entries and no corrupt JSON.
    await Promise.all([
      toggleSave(place, 'global'),
      toggleSave(place, 'global'),
    ]);

    const raw = storage.store.get(BOOKMARKS_KEY);
    assert.ok(raw !== undefined, 'bookmarks key must still exist in storage');

    const parsed = JSON.parse(raw!) as Array<{ id: string }>;
    const ids = parsed.map((p) => p.id);

    // No duplicates — the write queue prevented both calls from inserting at once
    const unique = new Set(ids);
    assert.equal(
      unique.size,
      ids.length,
      `expected no duplicate entries but got: ${JSON.stringify(ids)}`,
    );
  });
});
