import React from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';
import Svg, { Path, Defs, Pattern, Rect, Circle } from 'react-native-svg';
import { Plane, MapPin, MoreHorizontal, Camera } from 'lucide-react-native';
import type { OwnProfile, PublicProfile } from '../types/models';
import { PassportMonogramWatermark, PassportInkStamp, PassportHeroBackdrop } from './PassportMarks';
import { isTravelBuddyVerified, getVerificationOwnerPrompt } from '../lib/verification';
import { color, space, radius, type as t, shadow } from '../theme/tokens';
import { HighlightRing } from './HighlightRing';

const INTEREST_LABEL: Record<string, string> = {
  nightlife: 'Nightlife', food: 'Food', beach: 'Beach', luxury: 'Luxury',
  culture: 'Culture', adventure: 'Adventure', wellness: 'Wellness',
  photography: 'Photography', backpacking: 'Backpacking', shopping: 'Shopping',
  business: 'Business', dating: 'Social', events: 'Events',
};

function PhotoBackdrop() {
  return (
    <Svg style={StyleSheet.absoluteFill} viewBox="0 0 120 120" pointerEvents="none">
      <Defs>
        <Pattern id="wave2" width="20" height="20" patternUnits="userSpaceOnUse">
          <Path d="M0,10 Q5,2 10,10 T20,10" stroke={color.deep} strokeWidth="0.4" fill="none" opacity="0.18" />
        </Pattern>
      </Defs>
      <Rect x="0" y="0" width="120" height="120" fill="url(#wave2)" />
      {[28, 22, 16].map((r) => (
        <Circle key={r} cx="60" cy="60" r={r} stroke={color.deep} strokeWidth="0.5" fill="none" opacity="0.16" />
      ))}
    </Svg>
  );
}

/** Clean passport hero card — avatar, display name, username, bio (2 lines), home, up to 3 interests. */
export function PassportHero({
  profile,
  isOwner,
  onMenuPress,
  onAvatarPress,
  isFollowing,
  followLoading,
  followContext,
  onFollowPress,
  hasHighlights,
  allHighlightsViewed,
  onHighlightRingPress,
  onNewHighlightPress,
}: {
  profile: OwnProfile | PublicProfile;
  isOwner: boolean;
  onMenuPress?: () => void;
  onAvatarPress?: () => void;
  isFollowing?: boolean;
  followLoading?: boolean;
  followContext?: string;
  onFollowPress?: () => void;
  hasHighlights?: boolean;
  allHighlightsViewed?: boolean;
  onHighlightRingPress?: () => void;
  onNewHighlightPress?: () => void;
}) {
  const displayName = ('displayName' in profile ? profile.displayName : null) ?? profile.avatarUrl ?? 'Traveler';
  const name = ('name' in profile && profile.name) ? profile.name : null;
  const resolvedName = displayName || name || 'Traveler';
  const username = 'username' in profile ? profile.username : null;
  const bio = profile.bio;
  const homeCity = profile.homeCity;
  const homeCountry = profile.homeCountry;
  const interests = profile.interests ?? [];
  const shown = interests.slice(0, 3);
  const extra = interests.length - 3;
  const avatarUrl = profile.avatarUrl;
  const isVerified = isTravelBuddyVerified(profile);
  const verificationStatus = 'verificationStatus' in profile ? profile.verificationStatus : undefined;
  const ownerPrompt = isOwner ? getVerificationOwnerPrompt(verificationStatus) : null;

  return (
    <View style={styles.card}>
      <PassportHeroBackdrop />
      {isVerified && <View style={styles.inkStamp}><PassportInkStamp rotate={-8} /></View>}

      {/* Top label */}
      <View style={styles.topRow}>
        <View style={styles.brandRow}>
          <Plane size={16} color={color.ink} />
          <Text style={styles.brand}>TRAVEL BUDDY PASSPORT</Text>
        </View>
        {isOwner && onMenuPress ? (
          <Pressable onPress={onMenuPress} hitSlop={8} style={styles.menuBtn}>
            <MoreHorizontal size={20} color={color.ink} />
          </Pressable>
        ) : !isOwner && onFollowPress !== undefined ? (
          <View style={{ alignItems: 'flex-end', gap: 4 }}>
            <Pressable
              onPress={onFollowPress}
              hitSlop={8}
              disabled={followLoading}
              style={[styles.followBtn, isFollowing && styles.followBtnActive]}
            >
              <Text style={[styles.followText, isFollowing && styles.followTextActive]}>
                {followLoading ? '…' : isFollowing ? 'Following' : '+ Follow'}
              </Text>
            </Pressable>
            {followContext ? (
              <Text style={styles.followContextLabel}>{followContext}</Text>
            ) : null}
          </View>
        ) : null}
      </View>
      <View style={styles.topDivider} />

      {/* Identity row */}
      <View style={styles.identityRow}>
        {/* Avatar wrapped with HighlightRing */}
        <View style={styles.photoBox}>
          <PassportMonogramWatermark size={130} />
          <PhotoBackdrop />
          <HighlightRing
            hasActive={hasHighlights ?? false}
            allViewed={allHighlightsViewed ?? false}
            size={72}
            ringWidth={3}
            gap={3}
            onPress={onHighlightRingPress ?? (isOwner && onAvatarPress ? onAvatarPress : undefined)}
          >
            <View style={styles.photoFrame}>
              {avatarUrl ? (
                <Image source={{ uri: avatarUrl }} style={styles.photo} />
              ) : (
                <View style={[styles.photo, styles.photoEmpty]}>
                  <Text style={{ fontSize: 36 }}>👤</Text>
                </View>
              )}
            </View>
          </HighlightRing>
          {isOwner && onNewHighlightPress && (
            <Pressable
              style={styles.cameraOverlay}
              onPress={onNewHighlightPress}
              accessibilityLabel="Add new Highlight"
            >
              <Camera size={14} color={color.onInk} />
            </Pressable>
          )}
        </View>

        {/* Details */}
        <View style={styles.details}>
          <Text style={styles.name} numberOfLines={2}>{resolvedName}</Text>
          {username ? <Text style={styles.handle}>@{username}</Text> : null}
          {bio ? <Text style={styles.bio} numberOfLines={2}>{bio}</Text> : null}
          {(homeCity || homeCountry) ? (
            <View style={styles.locRow}>
              <MapPin size={12} color={color.deep} />
              <Text style={styles.loc} numberOfLines={1}>
                {[homeCity, homeCountry].filter(Boolean).join(', ')}
              </Text>
            </View>
          ) : null}
          {shown.length > 0 && (
            <View style={styles.interests}>
              {shown.map((i) => (
                <View key={i} style={styles.chip}>
                  <Text style={styles.chipText}>{INTEREST_LABEL[i] ?? i}</Text>
                </View>
              ))}
              {extra > 0 && (
                <View style={styles.chip}>
                  <Text style={styles.chipText}>+{extra}</Text>
                </View>
              )}
            </View>
          )}
        </View>
      </View>

      {/* Owner-only verification prompt (unverified / pending / rejected / expired) */}
      {!isVerified && ownerPrompt && (
        <View style={styles.verifyPrompt}>
          <Text style={styles.verifyPromptText}>{ownerPrompt}</Text>
        </View>
      )}

      {/* MRZ strip */}
      <View style={styles.mrzRow}>
        <Text style={styles.mrzChevron}>‹‹‹‹‹</Text>
        <Text style={styles.mrz} numberOfLines={1}>
          {isVerified
            ? 'TRAVEL BUDDY · VERIFIED TRAVEL ID · SOCIAL PASSPORT'
            : 'TRAVEL BUDDY · SOCIAL PASSPORT'}
        </Text>
        <Text style={styles.mrzChevron}>›››››</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    margin: space.lg,
    borderRadius: radius.lg,
    backgroundColor: '#FBFAF6',
    borderWidth: 1.5,
    borderColor: color.haze,
    padding: space.lg,
    overflow: 'hidden',
    ...shadow.card,
  },
  inkStamp: { position: 'absolute', top: 50, right: 12, zIndex: 1 },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: space.sm },
  brand: { ...t.bodyStrong, color: color.ink, letterSpacing: 0.5, fontSize: 13 },
  topDivider: { height: 1, backgroundColor: color.haze, marginVertical: space.md },

  menuBtn: { padding: 4 },
  followBtn: {
    borderWidth: 1, borderColor: color.ink, borderRadius: radius.pill,
    paddingHorizontal: space.md, paddingVertical: 5,
  },
  followBtnActive: { backgroundColor: color.ink },
  followText: { ...t.small, color: color.ink, fontWeight: '700' },
  followTextActive: { color: color.onInk },
  followContextLabel: { fontSize: 11, color: color.signal, fontWeight: '600' },

  identityRow: { flexDirection: 'row', gap: space.md },

  photoBox: { width: 110, alignItems: 'center', justifyContent: 'flex-start', paddingTop: 4 },
  photoFrame: {
    width: 96, height: 110,
    borderRadius: 8, borderWidth: 2, borderColor: color.paper,
    backgroundColor: color.haze, overflow: 'hidden', ...shadow.card,
  },
  photo: { width: '100%', height: '100%' },
  photoEmpty: { alignItems: 'center', justifyContent: 'center', backgroundColor: '#F0EDE8' },
  cameraOverlay: {
    position: 'absolute', bottom: 4, right: 4,
    backgroundColor: color.ink, borderRadius: 12, padding: 5,
    borderWidth: 1.5, borderColor: color.paper,
  },

  details: { flex: 1, gap: 6 },
  name: { ...t.heading, color: color.ink, fontSize: 22, lineHeight: 28 },
  handle: { ...t.small, color: color.mute, fontFamily: 'Courier', fontSize: 12 },
  bio: { ...t.body, color: color.ink, fontSize: 13, lineHeight: 18 },
  locRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  loc: { ...t.small, color: color.deep, fontWeight: '600', flex: 1, fontSize: 12 },
  interests: { flexDirection: 'row', flexWrap: 'wrap', gap: 5, marginTop: 2 },
  chip: {
    backgroundColor: color.paperRaised, borderRadius: radius.pill,
    paddingHorizontal: 8, paddingVertical: 3,
    borderWidth: 1, borderColor: color.haze,
  },
  chipText: { fontSize: 11, color: color.ink, fontWeight: '600' },

  mrzRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: space.sm, marginTop: space.md, paddingTop: space.md,
    borderTopWidth: 1, borderTopColor: color.haze,
  },
  mrz: { fontFamily: 'Courier', fontSize: 9, color: color.deep, letterSpacing: 1, fontWeight: '700', flex: 1, textAlign: 'center' },
  mrzChevron: { fontFamily: 'Courier', fontSize: 9, color: color.faint },
  verifyPrompt: {
    marginTop: space.sm, alignSelf: 'flex-start',
    backgroundColor: color.paperRaised, borderRadius: radius.pill,
    paddingHorizontal: space.md, paddingVertical: 4,
    borderWidth: 1, borderColor: color.haze,
  },
  verifyPromptText: { ...t.small, color: color.mute, fontWeight: '600', fontSize: 11 },
});
