/**
 * Geocoding-backed country resolution for stamps.
 *
 * Guards Task "recognize any city's country automatically": cities missing
 * from the static lookup resolve via geocoding (cached, deduplicated), and
 * failures still leave "XX" — never guessed. Also covers the XX-catalog
 * repair (re-key / merge) with a geocoding resolver.
 *
 * Run: node --import tsx/esm --test src/test/stampCountryGeocoder.test.ts
 */

import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import type { SupabaseClient } from "@supabase/supabase-js";

import {
  geocodeCityCountry,
  resolveCountryWithGeocoding,
  _setGeocodeFetchForTests,
  _setGeocodeDbClientForTests,
  _clearCountryGeocodeCache,
  _runCorrectionSweepForTests,
  _backdateGeocodeCacheEntryForTests,
  startCorrectionSweep,
} from "../lib/stamps/countryGeocoder.js";
import {
  repairXXCatalogEntries,
  makeGeocodingResolver,
  staticResolver,
} from "../lib/stamps/xxCatalogRepair.js";
import { wouldCreateDuplicateQueued, DUPLICATE_QUEUED_ERROR } from "./stampQueueConstraint.js";

// ── Fake fetch helpers ────────────────────────────────────────────────────────

let fetchCalls: string[] = [];

function fakeNominatim(results: Record<string, { country_code: string; country: string } | null>) {
  return async (url: string) => {
    fetchCalls.push(url);
    const q = decodeURIComponent(new URL(url).searchParams.get("q") ?? "").toLowerCase();
    const hit = results[q];
    return {
      ok: true,
      json: async () => (hit ? [{ address: { country_code: hit.country_code, country: hit.country } }] : []),
    };
  };
}

beforeEach(() => {
  fetchCalls = [];
  _clearCountryGeocodeCache();
  _setGeocodeFetchForTests(null);
  // Explicitly disable the DB client so tests that don't set one don't
  // accidentally fall through to the real Supabase client.  Tests that need
  // the persistent cache must call _setGeocodeDbClientForTests explicitly.
  _setGeocodeDbClientForTests(null);
});

// ── geocodeCityCountry ────────────────────────────────────────────────────────

describe("geocodeCityCountry", () => {
  it("resolves an unknown city's country via forward geocoding", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    const r = await geocodeCityCountry("Banff");
    assert.deepEqual(r, { country: "Canada", countryCode: "CA" });
  });

  it("prefers the canonical English country name from the static table", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "köln": { country_code: "de", country: "Deutschland" },
    }));
    const r = await geocodeCityCountry("Köln");
    assert.equal(r?.country, "Germany"); // not "Deutschland"
    assert.equal(r?.countryCode, "DE");
  });

  it("caches positive results — one fetch for repeated calls", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    await geocodeCityCountry("banff ");
    await geocodeCityCountry("BANFF");
    assert.equal(fetchCalls.length, 1);
  });

  it("returns null (never guesses) when geocoding finds nothing", async () => {
    _setGeocodeFetchForTests(fakeNominatim({}));
    assert.equal(await geocodeCityCountry("Nowhereville"), null);
  });

  it("returns null and caches negatively when the provider errors", async () => {
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      return { ok: false, status: 503, json: async () => ({}) };
    });
    assert.equal(await geocodeCityCountry("Banff"), null);
    assert.equal(await geocodeCityCountry("Banff"), null); // negative-cached
    assert.equal(fetchCalls.length, 1);
  });

  it("rejects invalid country codes from the provider", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "weird": { country_code: "canada", country: "Canada" },
    }));
    assert.equal(await geocodeCityCountry("Weird"), null);
  });
});

// ── Persistent DB cache ───────────────────────────────────────────────────────

interface GeoCacheRow { city_key: string; country: string; country_code: string; updated_at?: string; deleted_at?: string | null; corrected_at?: string | null }

function makeFakeGeoCacheDb(rows: GeoCacheRow[]) {
  const calls = { reads: 0, upserts: 0 };
  const client = {
    from(table: string) {
      assert.equal(table, "city_country_geocode_cache");
      let _key: string | null = null;
      const chain: any = {
        select() { return chain; },
        eq(_col: string, val: string) { _key = val; return chain; },
        async maybeSingle() {
          calls.reads += 1;
          return { data: rows.find((r) => r.city_key === _key) ?? null, error: null };
        },
        async upsert(row: GeoCacheRow) {
          calls.upserts += 1;
          const i = rows.findIndex((r) => r.city_key === row.city_key);
          if (i >= 0) rows[i] = row; else rows.push(row);
          return { error: null };
        },
      };
      return chain;
    },
  } as unknown as SupabaseClient;
  return { client, rows, calls };
}

describe("geocodeCityCountry persistent cache", () => {
  it("serves a persisted positive result without hitting the geocoder", async () => {
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("should not be called");
    });
    const db = makeFakeGeoCacheDb([{ city_key: "banff", country: "Canada", country_code: "CA" }]);
    _setGeocodeDbClientForTests(db.client);
    const r = await geocodeCityCountry("Banff");
    assert.deepEqual(r, { country: "Canada", countryCode: "CA" });
    assert.equal(fetchCalls.length, 0);

    // Now in the in-memory (L1) cache — repeat calls don't re-read the DB.
    await geocodeCityCountry("BANFF");
    assert.equal(db.calls.reads, 1);
  });

  it("persists positive geocode results to the DB", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "tromso": { country_code: "no", country: "Norway" },
    }));
    const db = makeFakeGeoCacheDb([]);
    _setGeocodeDbClientForTests(db.client);
    await geocodeCityCountry("Tromso");
    assert.equal(db.calls.upserts, 1);
    assert.deepEqual(db.rows[0].city_key, "tromso");
    assert.equal(db.rows[0].country_code, "NO");
    assert.equal(db.rows[0].country, "Norway");
  });

  it("does NOT persist negative results — failures stay retryable", async () => {
    _setGeocodeFetchForTests(fakeNominatim({}));
    const db = makeFakeGeoCacheDb([]);
    _setGeocodeDbClientForTests(db.client);
    assert.equal(await geocodeCityCountry("Nowhereville"), null);
    assert.equal(db.calls.upserts, 0);
  });

  it("falls through to geocoding when the DB cache errors", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    _setGeocodeDbClientForTests({
      from() { throw new Error("db down"); },
    } as unknown as SupabaseClient);
    const r = await geocodeCityCountry("Banff");
    assert.deepEqual(r, { country: "Canada", countryCode: "CA" });
  });

  it("ignores corrupt persisted rows and re-geocodes", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    const db = makeFakeGeoCacheDb([{ city_key: "banff", country: "Canada", country_code: "CANADA" }]);
    _setGeocodeDbClientForTests(db.client);
    const r = await geocodeCityCountry("Banff");
    assert.deepEqual(r, { country: "Canada", countryCode: "CA" });
    assert.equal(fetchCalls.length, 1);
  });

  it("rejects a tombstoned persisted row and falls back to Nominatim", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "us", country: "United States of America" },
    }));
    const db = makeFakeGeoCacheDb([
      {
        city_key: "banff",
        country: "Canada",
        country_code: "CA",
        // Backdated tombstone: it pre-dates the geocode start, so the fresh
        // result legitimately revives the row (writeDbCache's pre-upsert
        // re-check only protects tombstones written DURING the geocode).
        deleted_at: new Date(Date.now() - 60_000).toISOString(),
      },
    ]);
    _setGeocodeDbClientForTests(db.client);
    const r = await geocodeCityCountry("Banff");
    assert.deepEqual(r, { country: "United States", countryCode: "US" });
    assert.equal(fetchCalls.length, 1);
    // Two reads: readDbCache (tombstoned → miss) + writeDbCache's pre-upsert
    // tombstone re-check before persisting the fresh result.
    assert.equal(db.calls.reads, 2);
    assert.equal(db.calls.upserts, 1, "old tombstone is cleared — legitimate revival persists");
  });
});

// ── resolveCountryWithGeocoding ───────────────────────────────────────────────

describe("resolveCountryWithGeocoding", () => {
  it("uses the static lookup without any network call when possible", async () => {
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("should not be called");
    });
    const r = await resolveCountryWithGeocoding({ city: "London" });
    assert.equal(r.countryCode, "GB");
    assert.equal(fetchCalls.length, 0);
  });

  it("falls back to forward geocoding for cities the static lookup misses", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "tromso": { country_code: "no", country: "Norway" },
    }));
    const r = await resolveCountryWithGeocoding({ city: "Tromso" });
    assert.equal(r.countryCode, "NO");
    assert.equal(r.country, "Norway");
  });

  it("leaves XX when geocoding fails — never guesses", async () => {
    _setGeocodeFetchForTests(fakeNominatim({}));
    const r = await resolveCountryWithGeocoding({ city: "Nowhereville" });
    assert.equal(r.countryCode, "XX");
  });
});

// ── XX catalog repair with geocoding ──────────────────────────────────────────

type DB = Record<string, any[]>;

let idCounter = 0;
function nextId(): string {
  idCounter += 1;
  return `00000000-0000-4000-8000-${String(idCounter).padStart(12, "0")}`;
}

function makeFakeClient(db: DB): SupabaseClient {
  function buildChain(table: string) {
    const _filters: Array<(r: any) => boolean> = [];
    let _update: any = null;
    let _delete = false;
    let _maybeSingle = false;

    const rows = () => (db[table] ?? []);

    const chain: any = {
      select() { return chain; },
      update(data: any) { _update = data; return chain; },
      delete() { _delete = true; return chain; },
      eq(col: string, val: any) { _filters.push((r) => r[col] === val); return chain; },
      neq(col: string, val: any) { _filters.push((r) => r[col] !== val); return chain; },
      in(col: string, vals: any[]) { _filters.push((r) => vals.includes(r[col])); return chain; },
      is() { return chain; },
      not() { return chain; },
      maybeSingle() { _maybeSingle = true; return chain; },
      then(resolve: any) {
        return Promise.resolve().then(() => {
          if (!db[table]) db[table] = [];
          const matched = rows().filter((r) => _filters.every((f) => f(r)));
          if (_update) {
            // Partial unique index: one queued row per catalog_id
            if (
              table === "stamp_generation_queue" &&
              wouldCreateDuplicateQueued(rows(), matched, _update)
            ) {
              return resolve({ data: null, error: { ...DUPLICATE_QUEUED_ERROR } });
            }
            for (const r of matched) Object.assign(r, _update);
            return resolve({ data: matched, error: null });
          }
          if (_delete) {
            db[table] = rows().filter((r) => !matched.includes(r));
            return resolve({ data: null, error: null });
          }
          if (_maybeSingle) return resolve({ data: matched[0] ?? null, error: null });
          return resolve({ data: matched, error: null });
        });
      },
    };
    return chain;
  }
  return { from: (table: string) => buildChain(table) } as unknown as SupabaseClient;
}

const quietLog = { info: () => {}, warn: () => {} };

function freshDb(): DB {
  return {
    universal_stamp_catalog: [],
    user_stamps: [],
    passport_stamps: [],
    stamp_artwork_versions: [],
    stamp_generation_queue: [],
  };
}

describe("repairXXCatalogEntries", () => {
  it("re-keys an XX entry in place when the city geocodes and no survivor exists", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "tromso": { country_code: "no", country: "Norway" },
    }));
    const db = freshDb();
    db.universal_stamp_catalog.push({
      id: nextId(),
      canonical_location_key: "trip:xx:tromso",
      stamp_type: "trip",
      country: "Unknown",
      country_code: "XX",
      city: "Tromso",
      neighborhood: null,
      display_name: "Tromso",
      earn_count: 3,
    });
    const stats = await repairXXCatalogEntries(makeFakeClient(db), makeGeocodingResolver(), quietLog);
    assert.equal(stats.catalogRekeyed, 1);
    assert.equal(stats.geocodeResolved, 1);
    const entry = db.universal_stamp_catalog[0];
    assert.equal(entry.canonical_location_key, "trip:no:tromso");
    assert.equal(entry.country_code, "NO");
    assert.equal(entry.country, "Norway");
  });

  it("merges into an existing real-code entry: repoints ownership, transfers earn_count, deletes XX entry", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "tromso": { country_code: "no", country: "Norway" },
    }));
    const db = freshDb();
    const xxId = nextId();
    const realId = nextId();
    db.universal_stamp_catalog.push(
      {
        id: xxId, canonical_location_key: "trip:xx:tromso", stamp_type: "trip",
        country: "Unknown", country_code: "XX", city: "Tromso",
        neighborhood: null, display_name: "Tromso", earn_count: 2,
      },
      {
        id: realId, canonical_location_key: "trip:no:tromso", stamp_type: "trip",
        country: "Norway", country_code: "NO", city: "Tromso",
        neighborhood: null, display_name: "Tromso", earn_count: 5,
      },
    );
    db.user_stamps.push({ id: nextId(), catalog_id: xxId });
    db.stamp_artwork_versions.push({ id: nextId(), catalog_id: xxId });
    db.stamp_generation_queue.push({ id: nextId(), catalog_id: xxId, status: "queued" });

    const stats = await repairXXCatalogEntries(makeFakeClient(db), makeGeocodingResolver(), quietLog);
    assert.equal(stats.catalogMerged, 1);
    assert.equal(db.universal_stamp_catalog.length, 1);
    assert.equal(db.universal_stamp_catalog[0].id, realId);
    assert.equal(db.universal_stamp_catalog[0].earn_count, 7);
    assert.equal(db.user_stamps[0].catalog_id, realId);
    assert.equal(db.stamp_artwork_versions[0].catalog_id, realId);
    assert.equal(db.stamp_generation_queue.length, 0);
  });

  it("leaves genuinely unresolvable cities as XX and reports them", async () => {
    _setGeocodeFetchForTests(fakeNominatim({}));
    const db = freshDb();
    db.universal_stamp_catalog.push({
      id: nextId(),
      canonical_location_key: "trip:xx:nowhereville",
      stamp_type: "trip",
      country: "Unknown",
      country_code: "XX",
      city: "Nowhereville",
      neighborhood: null,
      display_name: "Nowhereville",
      earn_count: 1,
    });
    const stats = await repairXXCatalogEntries(makeFakeClient(db), makeGeocodingResolver(), quietLog);
    assert.equal(stats.catalogRekeyed, 0);
    assert.equal(stats.catalogMerged, 0);
    assert.deepEqual(stats.unresolvedCities, ["Nowhereville"]);
    assert.equal(db.universal_stamp_catalog[0].country_code, "XX");
  });

  it("skips definition-scoped (badge) entries which are intentionally XX", async () => {
    const db = freshDb();
    db.universal_stamp_catalog.push({
      id: nextId(),
      canonical_location_key: "definition:helpful-buddy",
      stamp_type: "social",
      country: "Global",
      country_code: "XX",
      city: null,
      neighborhood: null,
      display_name: "Helpful Buddy",
      earn_count: 4,
    });
    const stats = await repairXXCatalogEntries(makeFakeClient(db), staticResolver, quietLog);
    assert.equal(stats.scanned, 0);
    assert.equal(db.universal_stamp_catalog[0].canonical_location_key, "definition:helpful-buddy");
  });

  it("respects the geocode budget (maxGeocodes)", async () => {
    _setGeocodeFetchForTests(fakeNominatim({
      "cityone": { country_code: "fr", country: "France" },
      "citytwo": { country_code: "de", country: "Germany" },
    }));
    const db = freshDb();
    for (const city of ["CityOne", "CityTwo"]) {
      db.universal_stamp_catalog.push({
        id: nextId(),
        canonical_location_key: `trip:xx:${city.toLowerCase()}`,
        stamp_type: "trip",
        country: "Unknown",
        country_code: "XX",
        city,
        neighborhood: null,
        display_name: city,
        earn_count: 0,
      });
    }
    const stats = await repairXXCatalogEntries(
      makeFakeClient(db),
      makeGeocodingResolver({ maxGeocodes: 1 }),
      quietLog,
    );
    assert.equal(fetchCalls.length, 1);
    assert.equal(stats.catalogRekeyed, 1);
    assert.equal(stats.unresolvedCities.length, 1);
  });
});

// ── Background correction sweep ───────────────────────────────────────────────

/**
 * Build a minimal fake DB client whose city_country_geocode_cache table
 * returns a fixed list of rows for .select().gte() queries (the sweep pattern).
 */
function makeSweepDb(recentlyCorrectRows: Array<{ city_key: string; corrected_at: string }>) {
  const client = {
    from(table: string) {
      assert.equal(table, "city_country_geocode_cache");
      const chain: any = {
        select() { return chain; },
        gte() { return chain; },
        then(resolve: (v: any) => void) {
          resolve({ data: recentlyCorrectRows, error: null });
        },
      };
      return chain;
    },
  } as unknown as SupabaseClient;
  return client;
}

describe("background correction sweep", () => {
  it("evicts an in-memory entry whose writtenAt predates the DB corrected_at", async () => {
    // Seed the in-memory cache with a stale entry (writtenAt in the past).
    _setGeocodeFetchForTests(fakeNominatim({ "banff": { country_code: "ca", country: "Canada" } }));
    await geocodeCityCountry("Banff");                   // populates in-memory cache
    assert.equal(fetchCalls.length, 1);

    // DB reports that "banff" was corrected one second after the entry was written.
    const correctedAt = new Date(Date.now() + 1_000).toISOString(); // future = definitely after writtenAt
    _setGeocodeDbClientForTests(makeSweepDb([{ city_key: "banff", corrected_at: correctedAt }]));

    await _runCorrectionSweepForTests();

    // Cache entry should have been evicted; the next call re-resolves.
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 2, "should have re-geocoded after sweep eviction");
  });

  it("leaves an in-memory entry alone when writtenAt is newer than corrected_at", async () => {
    // Seed the in-memory cache.
    _setGeocodeFetchForTests(fakeNominatim({ "banff": { country_code: "ca", country: "Canada" } }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1);

    // DB reports a correction that happened BEFORE the cache entry was written.
    const correctedAt = new Date(Date.now() - 10_000).toISOString(); // 10 s in the past
    _setGeocodeDbClientForTests(makeSweepDb([{ city_key: "banff", corrected_at: correctedAt }]));

    await _runCorrectionSweepForTests();

    // Cache should still be valid; no new fetch.
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "cache entry should still be valid — no re-fetch expected");
  });

  it("is a no-op when the DB reports no recently-corrected rows", async () => {
    _setGeocodeFetchForTests(fakeNominatim({ "banff": { country_code: "ca", country: "Canada" } }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1);

    _setGeocodeDbClientForTests(makeSweepDb([])); // nothing corrected recently

    await _runCorrectionSweepForTests();

    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "empty sweep result should leave the cache untouched");
  });

  it("only evicts keys that are actually present in the in-memory cache", async () => {
    // DB reports a correction for "tromso", but it was never cached in memory.
    _setGeocodeDbClientForTests(
      makeSweepDb([{ city_key: "tromso", corrected_at: new Date().toISOString() }]),
    );
    // Should not throw or cause any issues.
    await _runCorrectionSweepForTests();
  });

  it("survives a DB error without throwing", async () => {
    const errorClient = {
      from() { throw new Error("db exploded"); },
    } as unknown as SupabaseClient;
    _setGeocodeDbClientForTests(errorClient);
    // Must not throw.
    await _runCorrectionSweepForTests();
  });

  it("startCorrectionSweep returns a stop function that clears the interval", () => {
    const stop = startCorrectionSweep(60_000);
    assert.equal(typeof stop, "function");
    // Calling stop must not throw.
    stop();
    // Calling stop a second time must also be safe.
    stop();
  });

  it("does not evict an in-memory entry when the DB row has corrected_at: null (sweep path)", async () => {
    // Seed in-memory cache with a valid entry.
    _setGeocodeFetchForTests(fakeNominatim({ "kyoto": { country_code: "jp", country: "Japan" } }));
    await geocodeCityCountry("Kyoto");
    assert.equal(fetchCalls.length, 1, "initial geocode should hit Nominatim once");

    // DB sweep returns the row for "kyoto" but with corrected_at: null.
    // SQL WHERE corrected_at >= since filters nulls, but if a null somehow
    // slips through the sweep must not treat it as an eviction signal.
    const nullCorrectedClient = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        const chain: any = {
          select() { return chain; },
          gte()    { return chain; },
          then(resolve: (v: any) => void) {
            resolve({ data: [{ city_key: "kyoto", corrected_at: null }], error: null });
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;
    _setGeocodeDbClientForTests(nullCorrectedClient);

    await _runCorrectionSweepForTests();

    // Entry must still be cached — no Nominatim re-fetch.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called — entry should still be cached");
    });
    _setGeocodeDbClientForTests(nullCorrectedClient);

    const r = await geocodeCityCountry("Kyoto");
    assert.equal(fetchCalls.length, 0, "null corrected_at must not evict the cache entry");
    assert.ok(r !== null, "cached result must still be returned");
    assert.equal(r!.countryCode, "JP");
  });

  it("mixed batch: only evicts the row with a valid corrected_at — null row stays cached", async () => {
    // Seed both cities into the in-memory cache.
    _setGeocodeFetchForTests(fakeNominatim({
      "kyoto": { country_code: "jp", country: "Japan" },
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Kyoto");
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 2, "both cities should have been geocoded initially");

    // DB sweep returns a mixed batch:
    //   - kyoto: corrected_at null  → must NOT be evicted
    //   - banff: corrected_at in the future → must be evicted
    const banffCorrectedAt = new Date(Date.now() + 1_000).toISOString();
    const mixedBatchClient = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let gteColumn = "";
        const chain: any = {
          select() { return chain; },
          gte(col: string) { gteColumn = col; return chain; },
          not()    { return chain; },
          in()     { return chain; },
          delete() { return chain; },
          then(resolve: (v: any) => void) {
            if (gteColumn === "corrected_at") {
              // Pass 1: return mixed batch with one null and one valid corrected_at.
              resolve({
                data: [
                  { city_key: "kyoto", corrected_at: null },
                  { city_key: "banff", corrected_at: banffCorrectedAt },
                ],
                error: null,
              });
            } else {
              // Pass 2 (deleted_at tombstone sweep): no tombstoned rows.
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;
    _setGeocodeDbClientForTests(mixedBatchClient);

    await _runCorrectionSweepForTests();

    // After the sweep: banff evicted, kyoto still cached.
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    _setGeocodeDbClientForTests(mixedBatchClient);

    // kyoto must still be served from cache — no Nominatim call.
    const kyotoResult = await geocodeCityCountry("Kyoto");
    assert.equal(fetchCalls.length, 0, "kyoto must still be cached — null corrected_at must not evict");
    assert.ok(kyotoResult !== null, "kyoto cached result must be returned");
    assert.equal(kyotoResult!.countryCode, "JP");

    // banff must have been evicted — the next call fires a new Nominatim fetch.
    const banffResult = await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "banff must have been evicted and re-geocoded");
    assert.ok(banffResult !== null, "banff result must be returned after re-geocode");
    assert.equal(banffResult!.countryCode, "CA");
  });

  it("three-city mixed batch: past correction kept, null skipped, future correction evicted", async () => {
    // Seed all three cities into the in-memory cache.
    _setGeocodeFetchForTests(fakeNominatim({
      "kyoto": { country_code: "jp", country: "Japan" },
      "paris": { country_code: "fr", country: "France" },
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Kyoto");
    await geocodeCityCountry("Paris");
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 3, "all three cities should have been geocoded initially");

    // DB sweep returns a three-entry mixed batch:
    //   - kyoto: corrected_at null          → must NOT be evicted
    //   - paris: corrected_at well in the past (pre-dates writtenAt) → must NOT be evicted
    //   - banff: corrected_at in the future (post-dates writtenAt)   → must be evicted
    const pastCorrectedAt   = new Date(Date.now() - 60_000).toISOString(); // 60 s ago — before writtenAt
    const futureCorrectedAt = new Date(Date.now() +  1_000).toISOString(); // 1 s ahead — after writtenAt
    const threeCityClient = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _gteColumn = "";
        const chain: any = {
          select() { return chain; },
          gte(col: string) { _gteColumn = col; return chain; },
          not()    { return chain; },
          in()     { return chain; },
          delete() { return chain; },
          then(resolve: (v: any) => void) {
            if (_gteColumn === "corrected_at") {
              // Pass 1: all three entries in the batch.
              resolve({
                data: [
                  { city_key: "kyoto", corrected_at: null },
                  { city_key: "paris", corrected_at: pastCorrectedAt },
                  { city_key: "banff", corrected_at: futureCorrectedAt },
                ],
                error: null,
              });
            } else {
              // Pass 2 (tombstone sweep): no tombstoned rows.
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;
    _setGeocodeDbClientForTests(threeCityClient);

    await _runCorrectionSweepForTests();

    // After the sweep: only banff should have been evicted.
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    _setGeocodeDbClientForTests(threeCityClient);

    // kyoto (null corrected_at) — must still be cached, no Nominatim call.
    const kyotoResult = await geocodeCityCountry("Kyoto");
    assert.equal(fetchCalls.length, 0, "kyoto must still be cached — null corrected_at must not evict");
    assert.ok(kyotoResult !== null, "kyoto cached result must be returned");
    assert.equal(kyotoResult!.countryCode, "JP");

    // paris (past corrected_at) — must still be cached, still no Nominatim call.
    const parisResult = await geocodeCityCountry("Paris");
    assert.equal(fetchCalls.length, 0, "paris must still be cached — past corrected_at must not evict");
    assert.ok(parisResult !== null, "paris cached result must be returned");
    assert.equal(parisResult!.countryCode, "FR");

    // banff (future corrected_at) — must have been evicted; one new Nominatim fetch.
    const banffResult = await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "banff must have been evicted and re-geocoded");
    assert.ok(banffResult !== null, "banff result must be returned after re-geocode");
    assert.equal(banffResult!.countryCode, "CA");
  });

  it("does not evict an in-memory entry when the DB row has corrected_at: null (per-request probe path)", async () => {
    // Seed in-memory cache with a valid entry.
    _setGeocodeFetchForTests(fakeNominatim({ "oslo": { country_code: "no", country: "Norway" } }));
    await geocodeCityCountry("Oslo");
    assert.equal(fetchCalls.length, 1, "initial geocode should hit Nominatim once");

    // Backdate the cache entry so the next geocodeCityCountry call immediately
    // re-probes the DB for corrected_at (skips the 5-minute cooldown).
    _backdateGeocodeCacheEntryForTests("oslo");

    // DB per-request probe returns a row with corrected_at: null.
    const nullCorrectedMaybeSingleClient = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          gte()         { return chain; },
          maybeSingle() { _isMaybeSingle = true; return chain; },
          then(resolve: (v: any) => void) {
            if (_isMaybeSingle) {
              // evictIfDbCorrected path — null corrected_at must not evict.
              resolve({ data: { corrected_at: null }, error: null });
            } else {
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;
    _setGeocodeDbClientForTests(nullCorrectedMaybeSingleClient);

    // Replace Nominatim with a failing stub — must never be called.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called — null corrected_at is not an eviction signal");
    });
    _setGeocodeDbClientForTests(nullCorrectedMaybeSingleClient);

    const r = await geocodeCityCountry("Oslo");
    assert.equal(fetchCalls.length, 0, "null corrected_at must not trigger a re-geocode");
    assert.ok(r !== null, "cached result must still be returned");
    assert.equal(r!.countryCode, "NO");
  });

  it("after sweep eviction re-resolves from the corrected DB row — zero Nominatim fetches", async () => {
    // Step 1: populate the in-memory cache with a stale entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "first resolve should hit Nominatim");

    // Step 2: an admin has since corrected the DB row to FR (a hypothetical admin override).
    // corrected_at is in the future relative to now so it definitely post-dates writtenAt.
    const correctedAt = new Date(Date.now() + 1_000).toISOString();

    // Build a combined fake DB client that serves:
    //   • the sweep query  (.select("city_key, corrected_at").gte("corrected_at", since))
    //   • the readDbCache  (.select("country, country_code, corrected_at").eq("city_key", key).maybeSingle())
    const correctedRow = {
      city_key: "banff",
      country: "France",
      country_code: "FR",
      corrected_at: correctedAt,
    };
    let dbReads = 0;
    const combinedDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        const chain: any = {
          select() { return chain; },
          eq()     { return chain; },
          gte()    { return chain; },
          maybeSingle() { _isMaybeSingle = true; return chain; },
          then(resolve: (v: any) => void) {
            dbReads += 1;
            if (_isMaybeSingle) {
              // readDbCache path: return the corrected row
              resolve({ data: correctedRow, error: null });
            } else {
              // sweep path: return the sweep list
              resolve({ data: [{ city_key: "banff", corrected_at: correctedAt }], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 3: run the sweep — it should evict the stale CA entry.
    _setGeocodeDbClientForTests(combinedDb);
    await _runCorrectionSweepForTests();

    // Step 4: now disable Nominatim entirely so any forward geocode call would fail.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called after sweep eviction");
    });

    // Step 5: geocodeCityCountry should re-resolve from the DB row only.
    const r = await geocodeCityCountry("Banff");

    assert.equal(fetchCalls.length, 0, "no Nominatim call should be made — DB row must be used");
    assert.ok(r !== null, "should return a resolved result");
    assert.equal(r!.countryCode, "FR", "should return the admin-corrected country code from the DB");
    assert.equal(r!.country, "France", "should return the admin-corrected country name from the DB");
    assert.ok(dbReads >= 2, "should have read the DB at least twice (sweep + readDbCache)");
  });

  it("after sweep eviction falls back to Nominatim when the DB row was deleted — not null", async () => {
    // Step 1: populate the in-memory cache with a stale entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "first resolve should hit Nominatim");

    // Step 2: the sweep DB returns a corrected_at that post-dates writtenAt,
    // but readDbCache returns null — the admin DELETE removed the row entirely.
    const correctedAt = new Date(Date.now() + 1_000).toISOString();
    const deletedDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        const chain: any = {
          select() { return chain; },
          eq()     { return chain; },
          gte()    { return chain; },
          maybeSingle() { _isMaybeSingle = true; return chain; },
          then(resolve: (v: any) => void) {
            if (_isMaybeSingle) {
              // readDbCache path: row was deleted — return null
              resolve({ data: null, error: null });
            } else {
              // sweep path: report the corrected_at so the entry is evicted
              resolve({ data: [{ city_key: "banff", corrected_at: correctedAt }], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 3: run the sweep — it should evict the stale CA entry.
    _setGeocodeDbClientForTests(deletedDb);
    await _runCorrectionSweepForTests();

    // Step 4: set up Nominatim to return a fresh result (GB for illustration).
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "gb", country: "United Kingdom" },
    }));

    // Step 5: geocodeCityCountry should fall through to Nominatim because
    // the DB row is gone — not return null.
    const r = await geocodeCityCountry("Banff");

    assert.equal(fetchCalls.length, 1, "exactly one Nominatim call should be made after deletion eviction");
    assert.ok(r !== null, "should return a resolved result — not stuck returning null");
    assert.equal(r!.countryCode, "GB", "should return the fresh Nominatim country code");
    assert.equal(r!.country, "United Kingdom", "should return the fresh Nominatim country name");
  });

  it("after deletion-eviction re-geocode, writes the fresh Nominatim result back to the DB", async () => {
    // Step 1: populate the in-memory cache with a stale entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "first resolve should hit Nominatim");

    // Step 2: build a DB client that:
    //   • for the sweep query returns a corrected_at post-dating writtenAt (triggers eviction)
    //   • for readDbCache (maybeSingle) returns null — the admin deleted the row entirely
    //   • records any upsert calls so the write-back can be verified
    const correctedAt = new Date(Date.now() + 1_000).toISOString();
    const upsertCalls: Array<{ city_key: string; country: string; country_code: string }> = [];
    const deletionDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          gte()         { return chain; },
          maybeSingle() { _isMaybeSingle = true; return chain; },
          async upsert(row: any) {
            upsertCalls.push(row);
            return { error: null };
          },
          then(resolve: (v: any) => void) {
            if (_isMaybeSingle) {
              // readDbCache path: row was deleted — return null
              resolve({ data: null, error: null });
            } else {
              // sweep path: signal eviction via a corrected_at that post-dates writtenAt
              resolve({ data: [{ city_key: "banff", corrected_at: correctedAt }], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 3: run the sweep — it should evict the stale CA entry.
    _setGeocodeDbClientForTests(deletionDb);
    await _runCorrectionSweepForTests();

    // Step 4: set up Nominatim to return a fresh result (GB for illustration).
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "gb", country: "United Kingdom" },
    }));

    // Step 5: geocodeCityCountry should re-resolve from Nominatim and persist
    // the fresh result back to the DB via exactly one upsert.
    const r = await geocodeCityCountry("Banff");

    assert.equal(fetchCalls.length, 1, "exactly one Nominatim call should be made after deletion eviction");
    assert.ok(r !== null, "should return a resolved result — not stuck returning null");
    assert.equal(r!.countryCode, "GB", "should return the fresh Nominatim country code");
    assert.equal(r!.country, "United Kingdom", "should return the fresh Nominatim country name");

    // The write-back assertion: the fresh result must be persisted via one upsert.
    assert.equal(upsertCalls.length, 1, "exactly one upsert must be made to persist the fresh geocode result");
    assert.equal(upsertCalls[0].city_key, "banff", "upsert must use the normalised city_key");
    assert.equal(upsertCalls[0].country_code, "GB", "upsert must carry the correct country_code");
    assert.equal(upsertCalls[0].country, "United Kingdom", "upsert must carry the correct country name");
  });

  it("after deletion-eviction re-geocode, the upsert payload explicitly sets deleted_at to null", async () => {
    // Step 1: populate the in-memory cache with a stale entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "first resolve should hit Nominatim");

    // Step 2: build a DB client that simulates a soft-deleted row (deleted_at set):
    //   • sweep query returns corrected_at post-dating writtenAt → triggers eviction
    //   • readDbCache (maybeSingle) returns null — the row is tombstoned
    //   • records the full upsert payload so deleted_at can be inspected
    const correctedAt = new Date(Date.now() + 1_000).toISOString();
    const upsertPayloads: Array<Record<string, unknown>> = [];
    const tombstonedDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          gte()         { return chain; },
          maybeSingle() { _isMaybeSingle = true; return chain; },
          async upsert(row: any) {
            upsertPayloads.push(row);
            return { error: null };
          },
          then(resolve: (v: any) => void) {
            if (_isMaybeSingle) {
              // readDbCache path: tombstoned row — treated as not found
              resolve({ data: null, error: null });
            } else {
              // sweep path: signal eviction
              resolve({ data: [{ city_key: "banff", corrected_at: correctedAt }], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 3: run the sweep — evicts the stale CA entry from the in-memory cache.
    _setGeocodeDbClientForTests(tombstonedDb);
    await _runCorrectionSweepForTests();

    // Step 4: configure Nominatim to return a fresh result (FR for this test).
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "fr", country: "France" },
    }));

    // Step 5: geocodeCityCountry resolves via Nominatim and writes back to the DB.
    const r = await geocodeCityCountry("Banff");

    assert.ok(r !== null, "should return a resolved result");
    assert.equal(r!.countryCode, "FR");

    // Core assertion: the write-back upsert must carry deleted_at: null so that
    // the previously tombstoned row is revived as a live cache entry. Without
    // this field, readDbCache would continue to filter out the row on the next
    // server restart and force an unnecessary Nominatim round-trip.
    assert.equal(upsertPayloads.length, 1, "exactly one upsert must be issued");
    assert.strictEqual(
      upsertPayloads[0].deleted_at,
      null,
      "upsert payload must explicitly set deleted_at to null to clear the soft-delete tombstone",
    );
    assert.equal(upsertPayloads[0].city_key, "banff", "upsert must use the normalised city_key");
    assert.equal(upsertPayloads[0].country_code, "FR", "upsert must carry the correct country_code");
    assert.equal(upsertPayloads[0].country, "France", "upsert must carry the correct country name");
  });

  it("Pass 2 does not evict a city whose deleted_at was cleared (revived) before the sweep's SELECT ran", async () => {
    // Step 1: seed the in-memory cache.
    _setGeocodeFetchForTests(fakeNominatim({
      "oslo": { country_code: "no", country: "Norway" },
    }));
    await geocodeCityCountry("Oslo");
    assert.equal(fetchCalls.length, 1, "initial geocode should hit Nominatim once");

    // Step 2: build a DB client that simulates a concurrent PUT that cleared
    // deleted_at BEFORE the sweep's Pass 2 SELECT ran.
    //   • Pass 1 (corrected_at gte): no recently-corrected rows.
    //   • Pass 2 (deleted_at gte + not null): returns [] — the .not("deleted_at",
    //     "is", null) guard filters out the revived row because deleted_at is now
    //     null, so the sweep sees zero tombstoned keys and issues no hard-delete.
    // If delete() were somehow called it would affect 0 rows; we track any call
    // so the assertion below can confirm it was skipped entirely.
    let deleteCalled = false;
    const revivedDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let gteColumn = "";
        const chain: any = {
          select()            { return chain; },
          gte(col: string)    { gteColumn = col; return chain; },
          not()               { return chain; },
          in()                { return chain; },
          delete()            { deleteCalled = true; return chain; },
          then(resolve: (v: any) => void) {
            if (gteColumn === "deleted_at") {
              // Pass 2: concurrent PUT already cleared deleted_at — no tombstones.
              resolve({ data: [], error: null });
            } else {
              // Pass 1: no recently-corrected rows.
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 3: run the sweep — Pass 2 should be a no-op for "oslo".
    _setGeocodeDbClientForTests(revivedDb);
    await _runCorrectionSweepForTests();

    // Step 4: the city must still be in the in-memory cache — no eviction,
    // no Nominatim re-fetch, no hard-delete.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called — oslo should still be in-memory cache");
    });
    _setGeocodeDbClientForTests(revivedDb);

    const r = await geocodeCityCountry("Oslo");
    assert.equal(fetchCalls.length, 0, "no Nominatim call should occur — revived city must be served from cache");
    assert.ok(r !== null, "revived city result must not be null");
    assert.equal(r!.countryCode, "NO", "revived city must return the original country code");
    assert.equal(r!.country, "Norway", "revived city must return the original country name");
    assert.equal(deleteCalled, false, "hard-delete must not be called when no tombstoned keys are found");
  });

  it("tombstone-sweep eviction: writes the fresh Nominatim result back to the DB", async () => {
    // Step 1: populate the in-memory cache with a stale entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "first resolve should hit Nominatim once");

    // Step 2: build a DB client that simulates the tombstone-sweep (Pass 2) path:
    //   • Pass 1 (corrected_at gte): no recently-corrected rows
    //   • Pass 2 (deleted_at gte + not null): "banff" row is tombstoned
    //   • delete(): succeeds (hard-delete of the tombstone row)
    //   • readDbCache (maybeSingle): returns null — row was hard-deleted
    //   • writeDbCache (upsert): records the call so the write-back can be verified
    const deletedAt = new Date(Date.now() + 1_000).toISOString();
    const upsertCalls: Array<{ city_key: string; country: string; country_code: string; updated_at?: string; deleted_at: string | null }> = [];
    const tombstoneDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        let _isDelete = false;
        let _gteColumn = "";
        const chain: any = {
          select()       { return chain; },
          eq()           { return chain; },
          gte(col: string) { _gteColumn = col; return chain; },
          not()          { return chain; },
          in()           { return chain; },
          delete()       { _isDelete = true; return chain; },
          maybeSingle()  { _isMaybeSingle = true; return chain; },
          async upsert(row: any) {
            upsertCalls.push(row);
            return { error: null };
          },
          then(resolve: (v: any) => void) {
            if (_isDelete) {
              // Hard-delete of tombstone rows — succeeds silently.
              resolve({ error: null });
            } else if (_isMaybeSingle) {
              // readDbCache path: row was hard-deleted — return null.
              resolve({ data: null, error: null });
            } else if (_gteColumn === "deleted_at") {
              // Pass 2 (tombstone sweep): "banff" has deleted_at set.
              resolve({ data: [{ city_key: "banff", deleted_at: deletedAt }], error: null });
            } else {
              // Pass 1 (corrected_at sweep): no recently-corrected rows.
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 3: run the sweep — Pass 2 should evict the in-memory "banff" entry.
    _setGeocodeDbClientForTests(tombstoneDb);
    await _runCorrectionSweepForTests();

    // Step 4: set up Nominatim to return a fresh result (GB for illustration).
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "gb", country: "United Kingdom" },
    }));

    // Step 5: geocodeCityCountry must fall through to Nominatim (readDbCache
    // returns null because the tombstone row was hard-deleted) and then write
    // the fresh result back to the DB via exactly one upsert.
    const r = await geocodeCityCountry("Banff");

    assert.equal(fetchCalls.length, 1, "exactly one Nominatim call should be made after tombstone eviction");
    assert.ok(r !== null, "should return a resolved result — not null");
    assert.equal(r!.countryCode, "GB", "should return the fresh Nominatim country code");
    assert.equal(r!.country, "United Kingdom", "should return the fresh Nominatim country name");

    // Write-back assertion: the fresh result must be persisted via one upsert.
    assert.equal(upsertCalls.length, 1, "exactly one upsert must be made to persist the fresh geocode result");
    assert.equal(upsertCalls[0].city_key, "banff", "upsert must use the normalised city_key");
    assert.equal(upsertCalls[0].country_code, "GB", "upsert must carry the correct country_code");
    assert.equal(upsertCalls[0].country, "United Kingdom", "upsert must carry the correct country name");
    assert.equal(
      upsertCalls[0].deleted_at,
      null,
      "upsert payload must explicitly set deleted_at to null to clear the soft-delete tombstone",
    );
  });

  it("tombstone-sweep eviction: repopulates the in-memory cache so the next call is served instantly", async () => {
    // Step 1: populate the in-memory cache with a stale entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "first resolve should hit Nominatim once");

    // Step 2: build a DB client that simulates the tombstone-sweep (Pass 2) path:
    //   • Pass 1 (corrected_at gte): no recently-corrected rows
    //   • Pass 2 (deleted_at gte + not null): "banff" row is tombstoned
    //   • delete(): hard-deletes the tombstone row
    //   • readDbCache (maybeSingle): returns null — row was hard-deleted
    //   • writeDbCache (upsert): succeeds silently
    const deletedAt = new Date(Date.now() + 1_000).toISOString();
    const tombstoneDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        let _isDelete = false;
        let _gteColumn = "";
        const chain: any = {
          select()       { return chain; },
          eq()           { return chain; },
          gte(col: string) { _gteColumn = col; return chain; },
          not()          { return chain; },
          in()           { return chain; },
          delete()       { _isDelete = true; return chain; },
          maybeSingle()  { _isMaybeSingle = true; return chain; },
          async upsert(_row: any) { return { error: null }; },
          then(resolve: (v: any) => void) {
            if (_isDelete) {
              // Hard-delete of tombstone rows — succeeds silently.
              resolve({ error: null });
            } else if (_isMaybeSingle) {
              // readDbCache path: row was hard-deleted — return null.
              resolve({ data: null, error: null });
            } else if (_gteColumn === "deleted_at") {
              // Pass 2 (tombstone sweep): "banff" has deleted_at set.
              resolve({ data: [{ city_key: "banff", deleted_at: deletedAt }], error: null });
            } else {
              // Pass 1 (corrected_at sweep): no recently-corrected rows.
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 3: run the sweep — Pass 2 should evict the in-memory "banff" entry.
    _setGeocodeDbClientForTests(tombstoneDb);
    await _runCorrectionSweepForTests();

    // Step 4: set up Nominatim to return a fresh result (GB for illustration).
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "gb", country: "United Kingdom" },
    }));

    // Step 5: first call after eviction re-geocodes and repopulates the cache.
    const r1 = await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "exactly one Nominatim call should be made after tombstone eviction");
    assert.ok(r1 !== null, "should return a resolved result");
    assert.equal(r1!.countryCode, "GB", "should return the fresh Nominatim country code");
    assert.equal(r1!.country, "United Kingdom", "should return the fresh Nominatim country name");

    // Step 6: second call must be served directly from the in-memory cache —
    // no extra Nominatim fetch, no DB read, and the same result as the first call.
    const r2 = await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "second call must not trigger another Nominatim fetch");
    assert.deepEqual(r2, r1, "second call must return the same result as the first");
  });

  it("after deletion-eviction re-geocode, a writeDbCache failure still returns the fresh result and caches it in-memory", async () => {
    // Step 1: populate the in-memory cache with an initial positive entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "first resolve should hit Nominatim once");

    // Step 2: backdate the cache entry so the correction-check interval has elapsed
    // and evictIfDbCorrected is called on the very next geocodeCityCountry call.
    _backdateGeocodeCacheEntryForTests("banff");

    // Step 3: build a DB client where:
    //   • the correction probe (maybeSingle) returns null — row deleted — triggers deletion eviction
    //   • readDbCache (second maybeSingle) also returns null — row is still gone
    //   • upsert (writeDbCache write-back) returns an error to simulate a transient DB outage
    let maybeSingleCalls = 0;
    const failingWriteDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          maybeSingle() { maybeSingleCalls += 1; return chain; },
          async upsert(_row: any) {
            return { error: { message: "transient DB write failure" } };
          },
          then(resolve: (v: any) => void) {
            // Both the correction probe and readDbCache paths see a deleted row.
            resolve({ data: null, error: null });
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 4: inject Nominatim returning a fresh GB result, and the failing DB client.
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "gb", country: "United Kingdom" },
    }));
    _setGeocodeDbClientForTests(failingWriteDb);

    // Step 5: geocodeCityCountry must return the fresh Nominatim result even though
    // writeDbCache later returns an error.
    const r = await geocodeCityCountry("Banff");

    assert.equal(fetchCalls.length, 1, "exactly one Nominatim call should be made after deletion eviction");
    assert.ok(r !== null, "should return the fresh result — not null — despite writeDbCache failure");
    assert.equal(r!.countryCode, "GB", "should return the fresh Nominatim country code");
    assert.equal(r!.country, "United Kingdom", "should return the fresh Nominatim country name");
    assert.ok(maybeSingleCalls >= 2, "DB should be probed at least twice (correction probe + readDbCache)");

    // Step 6: confirm the fresh result is held in the in-memory cache — a second
    // call must not hit Nominatim at all, even though the DB write failed.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called — fresh result should be in-memory cache");
    });
    _setGeocodeDbClientForTests(failingWriteDb);

    const r2 = await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 0, "second call must not hit Nominatim — fresh result is cached in-memory");
    assert.ok(r2 !== null, "in-memory cached result must not be null");
    assert.equal(r2!.countryCode, "GB", "in-memory cache must hold the fresh country code");
    assert.equal(r2!.country, "United Kingdom", "in-memory cache must hold the fresh country name");
  });

  it("persist_failed log event fires (with correct city_key) when the writeDbCache upsert returns an error", async () => {
    // Step 1: seed in-memory cache with an initial positive result.
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");

    // Step 2: backdate so the correction-check interval has elapsed and
    // evictIfDbCorrected runs on the very next geocodeCityCountry call.
    _backdateGeocodeCacheEntryForTests("banff");

    // Step 3: build a DB client where:
    //   • the correction probe (maybeSingle / then) sees a deleted row → deletion eviction
    //   • readDbCache (second maybeSingle) also returns null
    //   • upsert returns an error to simulate a transient DB outage
    let maybeSingleCalls = 0;
    const failingWriteDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          maybeSingle() { maybeSingleCalls += 1; return chain; },
          async upsert(_row: any) {
            return { error: { message: "transient DB write failure" } };
          },
          then(resolve: (v: any) => void) {
            resolve({ data: null, error: null });
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 4: inject a fresh Nominatim result (GB) and the failing DB client.
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "gb", country: "United Kingdom" },
    }));
    _setGeocodeDbClientForTests(failingWriteDb);

    // Step 5: capture stdout to intercept logEvent output.
    const logged: string[] = [];
    const origWrite = process.stdout.write.bind(process.stdout);
    process.stdout.write = (chunk: any, ...rest: any[]) => {
      logged.push(typeof chunk === "string" ? chunk : chunk.toString());
      return (origWrite as any)(chunk, ...rest);
    };

    let r: any;
    try {
      r = await geocodeCityCountry("Banff");
    } finally {
      process.stdout.write = origWrite;
    }

    // Step 6: assert the fresh result is still returned despite the DB failure.
    assert.ok(r !== null, "should return the fresh geocode result even when writeDbCache errors");
    assert.equal(r!.countryCode, "GB", "should carry the fresh Nominatim country code");
    assert.equal(r!.country, "United Kingdom", "should carry the fresh Nominatim country name");

    // Step 7: assert persist_failed was logged with the correct city_key.
    const persistFailedLines = logged
      .flatMap((chunk) => chunk.split("\n"))
      .filter((line) => line.trim().startsWith("{"))
      .map((line) => { try { return JSON.parse(line); } catch { return null; } })
      .filter(Boolean)
      .filter((obj: any) => obj.event === "stamp.country_geocode.persist_failed");

    assert.ok(
      persistFailedLines.length >= 1,
      `expected at least one 'stamp.country_geocode.persist_failed' log line, got: ${JSON.stringify(logged)}`,
    );
    assert.equal(
      persistFailedLines[0].city_key,
      "banff",
      "persist_failed must include the normalised city_key",
    );
    assert.equal(
      persistFailedLines[0].error,
      "transient DB write failure",
      "persist_failed must carry the readable error message from the failed upsert",
    );
  });

  it("persist_failed carries the thrown error's message when the writeDbCache upsert throws", async () => {
    // Step 1: seed in-memory cache with an initial positive result.
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");

    // Step 2: backdate so the correction-check probe runs on the next call.
    _backdateGeocodeCacheEntryForTests("banff");

    // Step 3: DB client where the probe sees a deleted row (eviction), readDbCache
    // returns null, and upsert THROWS (instead of returning { error }).
    const throwingWriteDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          maybeSingle() { return chain; },
          async upsert(_row: any) {
            throw new Error("connection reset during upsert");
          },
          then(resolve: (v: any) => void) {
            resolve({ data: null, error: null });
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 4: fresh Nominatim result + throwing DB client.
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "gb", country: "United Kingdom" },
    }));
    _setGeocodeDbClientForTests(throwingWriteDb);

    // Step 5: capture stdout to intercept logEvent output.
    const logged: string[] = [];
    const origWrite = process.stdout.write.bind(process.stdout);
    process.stdout.write = (chunk: any, ...rest: any[]) => {
      logged.push(typeof chunk === "string" ? chunk : chunk.toString());
      return (origWrite as any)(chunk, ...rest);
    };

    let r: any;
    try {
      r = await geocodeCityCountry("Banff");
    } finally {
      process.stdout.write = origWrite;
    }

    // Step 6: fresh result still returned despite the thrown DB error.
    assert.ok(r !== null, "should return the fresh geocode result even when writeDbCache throws");
    assert.equal(r!.countryCode, "GB", "should carry the fresh Nominatim country code");

    // Step 7: persist_failed logged with city_key AND the thrown error's message.
    const persistFailedLines = logged
      .flatMap((chunk) => chunk.split("\n"))
      .filter((line) => line.trim().startsWith("{"))
      .map((line) => { try { return JSON.parse(line); } catch { return null; } })
      .filter(Boolean)
      .filter((obj: any) => obj.event === "stamp.country_geocode.persist_failed");

    assert.ok(
      persistFailedLines.length >= 1,
      `expected at least one 'stamp.country_geocode.persist_failed' log line, got: ${JSON.stringify(logged)}`,
    );
    assert.equal(
      persistFailedLines[0].city_key,
      "banff",
      "persist_failed must include the normalised city_key",
    );
    assert.equal(
      persistFailedLines[0].error,
      "connection reset during upsert",
      "persist_failed must carry the thrown error's message so operators can diagnose the outage",
    );
  });

  it("bumps correctionCheckedAt after a no-op probe (corrected_at pre-dates writtenAt) — second call skips the probe", async () => {
    // Step 1: seed the in-memory cache with a valid entry. Use a working DB
    // client so the seed persist succeeds — otherwise persistFailed retries
    // on later warm hits would add extra maybeSingle calls to the probe count.
    _setGeocodeFetchForTests(fakeNominatim({ "oslo": { country_code: "no", country: "Norway" } }));
    _setGeocodeDbClientForTests(makeFakeGeoCacheDb([]).client);
    await geocodeCityCountry("Oslo");
    assert.equal(fetchCalls.length, 1, "initial geocode should hit Nominatim once");

    // Step 2: backdate the cache entry so the next call immediately re-probes
    // the DB for corrected_at (skips the 5-minute cooldown).
    _backdateGeocodeCacheEntryForTests("oslo");

    // Step 3: build a DB client that returns corrected_at that pre-dates
    // writtenAt — so evictIfDbCorrected returns false (no eviction).
    // Track how many times the probe path is exercised.
    let dbProbeCalls = 0;
    const staleCorrection = new Date(Date.now() - 60_000).toISOString(); // older than writtenAt
    const noOpDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          gte()         { return chain; },
          maybeSingle() { _isMaybeSingle = true; return chain; },
          then(resolve: (v: any) => void) {
            if (_isMaybeSingle) {
              dbProbeCalls += 1;
              // corrected_at pre-dates writtenAt — no eviction should occur.
              resolve({ data: { corrected_at: staleCorrection, deleted_at: null }, error: null });
            } else {
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;
    _setGeocodeDbClientForTests(noOpDb);

    // Step 4: replace Nominatim with a stub that must never be called —
    // the cached entry should survive the no-op probe intact.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called — entry is still cached");
    });
    // First call — the backdated timestamp triggers the probe; DB returns a
    // stale corrected_at so no eviction occurs. correctionCheckedAt is bumped.
    const r1 = await geocodeCityCountry("Oslo");
    assert.equal(dbProbeCalls, 1, "DB must be probed exactly once on the first call");
    assert.equal(fetchCalls.length, 0, "Nominatim must not be called after a no-op probe");
    assert.ok(r1 !== null, "cached result must still be returned after the no-op probe");
    assert.equal(r1!.countryCode, "NO");

    // Step 5: second call without backdating — correctionCheckedAt was bumped
    // to Date.now() by the first call, so the interval has not elapsed yet.
    // The probe must be skipped entirely.
    const r2 = await geocodeCityCountry("Oslo");
    assert.equal(dbProbeCalls, 1, "DB must NOT be probed a second time — correctionCheckedAt was bumped");
    assert.equal(fetchCalls.length, 0, "Nominatim must not be called on the second hit either");
    assert.ok(r2 !== null, "cached result must still be returned on the second call");
    assert.equal(r2!.countryCode, "NO");
  });

  it("deletion-eviction re-geocode returning null is cached in-memory — not retried on the next call", async () => {
    // Step 1: seed the in-memory cache with an initial positive entry (CA for Banff).
    _setGeocodeFetchForTests(fakeNominatim({
      "banff": { country_code: "ca", country: "Canada" },
    }));
    await geocodeCityCountry("Banff");
    assert.equal(fetchCalls.length, 1, "initial geocode should hit Nominatim once");

    // Step 2: backdate correctionCheckedAt so the very next call immediately
    // re-probes the DB for corrected_at / deleted_at (skips the 5-min cooldown).
    _backdateGeocodeCacheEntryForTests("banff");

    // Step 3: build a DB client where both maybeSingle() calls (the correction
    // probe inside evictIfDbCorrected and the subsequent readDbCache call) return
    // data: null — simulating a row that was hard-deleted by an admin.
    let maybeSingleCalls = 0;
    const deletedRowDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          maybeSingle() { maybeSingleCalls += 1; return chain; },
          then(resolve: (v: any) => void) {
            // Both the correction probe and readDbCache paths see a missing row.
            resolve({ data: null, error: null });
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;

    // Step 4: configure Nominatim to return no result for "banff" — the city is
    // unresolvable this time around (e.g. Nominatim has no match).
    fetchCalls = [];
    _setGeocodeFetchForTests(fakeNominatim({})); // empty → no match
    _setGeocodeDbClientForTests(deletedRowDb);

    // Step 5: first call — correction probe fires, evictIfDbCorrected sees data: null
    // and evicts the stale CA entry.  readDbCache also returns null.  Nominatim is
    // called but returns null too.  The null result must be negative-cached.
    const r1 = await geocodeCityCountry("Banff");
    assert.equal(r1, null, "first call must return null — city is unresolvable");
    assert.equal(fetchCalls.length, 1, "Nominatim must be called exactly once on the first call");
    assert.ok(maybeSingleCalls >= 2, "DB must be probed at least twice (correction probe + readDbCache)");

    // Step 6: second call — the null result is held in the in-memory cache under
    // NEGATIVE_TTL_MS.  Nominatim must NOT be called again; the cached null is returned.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called — null result is negative-cached");
    });

    const r2 = await geocodeCityCountry("Banff");
    assert.equal(r2, null, "second call must also return null — served from in-memory negative cache");
    assert.equal(fetchCalls.length, 0, "Nominatim must not be called a second time — null is already cached");
  });

  it("bumps correctionCheckedAt after a transient DB error — second call skips the probe", async () => {
    // Step 1: seed the in-memory cache with a valid entry. Use a working DB
    // client so the seed persist succeeds — otherwise persistFailed retries
    // on later warm hits would add extra maybeSingle calls to the probe count.
    _setGeocodeFetchForTests(fakeNominatim({ "reykjavik": { country_code: "is", country: "Iceland" } }));
    _setGeocodeDbClientForTests(makeFakeGeoCacheDb([]).client);
    await geocodeCityCountry("Reykjavik");
    assert.equal(fetchCalls.length, 1, "initial geocode should hit Nominatim once");

    // Step 2: backdate the cache entry so the next call immediately re-probes
    // the DB for corrected_at (skips the 5-minute cooldown).
    _backdateGeocodeCacheEntryForTests("reykjavik");

    // Step 3: build a DB client that returns an error on maybeSingle() and
    // records how many times the probe path is exercised.
    let dbProbeCalls = 0;
    const errorDb = {
      from(table: string) {
        assert.equal(table, "city_country_geocode_cache");
        let _isMaybeSingle = false;
        const chain: any = {
          select()      { return chain; },
          eq()          { return chain; },
          gte()         { return chain; },
          maybeSingle() { _isMaybeSingle = true; return chain; },
          then(resolve: (v: any) => void) {
            if (_isMaybeSingle) {
              dbProbeCalls += 1;
              // Simulate a transient DB error — evictIfDbCorrected returns false.
              resolve({ data: null, error: { message: "connection timeout" } });
            } else {
              resolve({ data: [], error: null });
            }
          },
        };
        return chain;
      },
    } as unknown as SupabaseClient;
    _setGeocodeDbClientForTests(errorDb);

    // Step 4: replace Nominatim with a stub that must never be called.
    fetchCalls = [];
    _setGeocodeFetchForTests(async (url: string) => {
      fetchCalls.push(url);
      throw new Error("Nominatim must not be called — entry is still cached");
    });
    // First call — the backdated timestamp triggers the probe; DB errors out.
    const r1 = await geocodeCityCountry("Reykjavik");
    assert.equal(dbProbeCalls, 1, "DB must be probed exactly once on the first call");
    assert.equal(fetchCalls.length, 0, "Nominatim must not be called after a DB error");
    assert.ok(r1 !== null, "cached result must still be returned despite the DB error");
    assert.equal(r1!.countryCode, "IS");

    // Step 5: second call without backdating — correctionCheckedAt was bumped
    // to Date.now() by the first call, so the interval has not elapsed yet.
    // The probe must be skipped entirely.
    const r2 = await geocodeCityCountry("Reykjavik");
    assert.equal(dbProbeCalls, 1, "DB must NOT be probed a second time — correctionCheckedAt was bumped");
    assert.equal(fetchCalls.length, 0, "Nominatim must not be called on the second hit either");
    assert.ok(r2 !== null, "cached result must still be returned on the second call");
    assert.equal(r2!.countryCode, "IS");
  });
});
