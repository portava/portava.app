/**
 * Tests for POST /api/discovery/community — required field validation, duplicate detection,
 * and DB insert failure handling
 *
 * Uses _setTestClient to inject a fake Supabase service client, bypassing the
 * real DB entirely. No network calls are made.
 *
 * Tests cover:
 *  - missing city returns 400 invalid_payload
 *  - empty city string returns 400 invalid_payload
 *  - missing name returns 400 invalid_payload
 *  - empty name string returns 400 invalid_payload
 *  - missing place_type returns 400 invalid_payload
 *  - invalid place_type value returns 400 invalid_payload
 *  - valid body with both valid place_type values returns 201
 *  - duplicate city+name (active) returns 409 duplicate_place
 *  - first submission (no existing place) returns 201
 *  - DB insert error returns 500 with structured error body
 *
 * Run: node --import tsx/esm --test src/test/discoveryCommunityRequiredFields.test.ts
 */
import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import type { Server } from "node:http";
import app from "../app.js";
import { _setTestClient } from "../lib/http.js";

// ── Constants ──────────────────────────────────────────────────────────────────

const FAKE_TOKEN = "community-required-fields-test-token";
const USER_ID    = "user-community-required-1";

const VALID_BODY = {
  city:       "Lisbon",
  name:       "Pastéis de Belém",
  place_type: "hidden_gem",
  category:   "food",
  lat:        38.6976,
  lng:        -9.2031,
};

// ── Fake client ────────────────────────────────────────────────────────────────

function makeFakeClient({
  duplicateExists = false,
  insertFails = false,
  dupeCheckFails = false,
}: { duplicateExists?: boolean; insertFails?: boolean; dupeCheckFails?: boolean } = {}) {
  const insertedRow = {
    id:         "place-required-1",
    name:       VALID_BODY.name,
    city:       VALID_BODY.city,
    place_type: VALID_BODY.place_type,
    status:     "active",
    created_at: "2025-07-01T00:00:00.000Z",
  };

  const existingRow = { id: "place-existing-1" };

  function chain() {
    let _singleMode      = false;
    let _maybeSingleMode = false;
    let _isInsert        = false;

    const obj: any = {
      select()      { return obj; },
      insert()      { _isInsert = true; return obj; },
      eq()          { return obj; },
      ilike()       { return obj; },
      limit()       { return obj; },
      single()      { _singleMode = true; return obj; },
      maybeSingle() { _maybeSingleMode = true; return obj; },
      then(onF: any, onR: any) { return resolve().then(onF, onR); },
    };

    async function resolve(): Promise<{ data: any; error: any }> {
      if (_maybeSingleMode) {
        if (dupeCheckFails) {
          return { data: null, error: { message: "dupe check db error" } };
        }
        return { data: duplicateExists ? existingRow : null, error: null };
      }
      if (_isInsert) {
        if (insertFails) {
          return { data: null, error: { message: "db error" } };
        }
        return { data: _singleMode ? insertedRow : [insertedRow], error: null };
      }
      return { data: _singleMode ? insertedRow : [insertedRow], error: null };
    }

    return obj;
  }

  return {
    from(_table: string) { return chain(); },
    auth: {
      getUser: async (token: string) => {
        if (token === FAKE_TOKEN) {
          return { data: { user: { id: USER_ID } }, error: null };
        }
        return { data: { user: null }, error: { message: "invalid token" } };
      },
    },
  };
}

// ── HTTP helpers ───────────────────────────────────────────────────────────────

function startServer(): Promise<{ server: Server; url: string }> {
  return new Promise((resolve) => {
    const server = createServer(app);
    server.listen(0, "127.0.0.1", () => {
      const port = (server.address() as any).port as number;
      resolve({ server, url: `http://127.0.0.1:${port}` });
    });
  });
}

function closeServer(server: Server): Promise<void> {
  return new Promise((resolve) => server.close(() => resolve()));
}

async function post(url: string, path: string, body: Record<string, unknown>) {
  const res = await fetch(`${url}${path}`, {
    method:  "POST",
    headers: {
      "content-type":  "application/json",
      "authorization": `Bearer ${FAKE_TOKEN}`,
    },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: (await res.json()) as any };
}

// ── Tests ──────────────────────────────────────────────────────────────────────

describe("POST /api/discovery/community — required field validation", () => {
  let server: Server;
  let url: string;

  beforeEach(async () => {
    ({ server, url } = await startServer());
    _setTestClient(makeFakeClient(), true);
  });

  afterEach(async () => {
    _setTestClient(null, false);
    await closeServer(server);
  });

  // ── city ────────────────────────────────────────────────────────────────────

  it("returns 400 when city is missing", async () => {
    const { city: _omit, ...body } = VALID_BODY;
    const r = await post(url, "/api/discovery/community", body);
    assert.equal(r.status, 400, `expected 400 for missing city, got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  it("returns 400 when city is an empty string", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, city: "" });
    assert.equal(r.status, 400, `expected 400 for city="", got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  it("returns 400 when city is whitespace only", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, city: "   " });
    assert.equal(r.status, 400, `expected 400 for city="   ", got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  // ── name ────────────────────────────────────────────────────────────────────

  it("returns 400 when name is missing", async () => {
    const { name: _omit, ...body } = VALID_BODY;
    const r = await post(url, "/api/discovery/community", body);
    assert.equal(r.status, 400, `expected 400 for missing name, got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  it("returns 400 when name is an empty string", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, name: "" });
    assert.equal(r.status, 400, `expected 400 for name="", got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  it("returns 400 when name is whitespace only", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, name: "   " });
    assert.equal(r.status, 400, `expected 400 for name="   ", got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  // ── place_type ──────────────────────────────────────────────────────────────

  it("returns 400 when place_type is missing", async () => {
    const { place_type: _omit, ...body } = VALID_BODY;
    const r = await post(url, "/api/discovery/community", body);
    assert.equal(r.status, 400, `expected 400 for missing place_type, got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  it("returns 400 when place_type is an unrecognised value", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, place_type: "unknown_type" });
    assert.equal(r.status, 400, `expected 400 for place_type="unknown_type", got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  it("returns 400 when place_type is an empty string", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, place_type: "" });
    assert.equal(r.status, 400, `expected 400 for place_type="", got ${r.status}`);
    assert.equal(r.body.error, "invalid_payload");
  });

  // ── happy paths (one per allowed place_type) ────────────────────────────────

  it("accepts place_type=hidden_gem and returns 201", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, place_type: "hidden_gem" });
    assert.equal(r.status, 201, `expected 201 for place_type="hidden_gem", got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.ok, true);
  });

  it("accepts place_type=traveler_pick and returns 201", async () => {
    const r = await post(url, "/api/discovery/community", { ...VALID_BODY, place_type: "traveler_pick" });
    assert.equal(r.status, 201, `expected 201 for place_type="traveler_pick", got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.ok, true);
  });
});

describe("POST /api/discovery/community — duplicate detection", () => {
  let server: Server;
  let url: string;

  afterEach(async () => {
    _setTestClient(null, false);
    await closeServer(server);
  });

  it("returns 409 with duplicate_place when the same city+name (active) already exists", async () => {
    ({ server, url } = await startServer());
    _setTestClient(makeFakeClient({ duplicateExists: true }), true);

    const r = await post(url, "/api/discovery/community", VALID_BODY);
    assert.equal(r.status, 409, `expected 409 for duplicate, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error, "duplicate_place");
  });

  it("returns 201 when no existing active place matches city+name (first submission)", async () => {
    ({ server, url } = await startServer());
    _setTestClient(makeFakeClient({ duplicateExists: false }), true);

    const r = await post(url, "/api/discovery/community", VALID_BODY);
    assert.equal(r.status, 201, `expected 201 for first submission, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.ok, true);
  });
});

describe("POST /api/discovery/community — duplicate-check DB error", () => {
  let server: Server;
  let url: string;

  beforeEach(async () => {
    ({ server, url } = await startServer());
    _setTestClient(makeFakeClient({ dupeCheckFails: true }), true);
  });

  afterEach(async () => {
    _setTestClient(null, false);
    await closeServer(server);
  });

  it("does not return 201 when the duplicate-check query itself fails", async () => {
    const r = await post(url, "/api/discovery/community", VALID_BODY);
    assert.notEqual(r.status, 201, `expected non-201 when dupe check fails, got ${r.status}: ${JSON.stringify(r.body)}`);
  });

  it("returns a non-empty error code when the duplicate-check query itself fails", async () => {
    const r = await post(url, "/api/discovery/community", VALID_BODY);
    assert.ok(
      typeof r.body.error === "string" && r.body.error.length > 0,
      `expected a non-empty error code in response, got: ${JSON.stringify(r.body)}`,
    );
  });
});

describe("POST /api/discovery/community — DB insert failure", () => {
  let server: Server;
  let url: string;

  beforeEach(async () => {
    ({ server, url } = await startServer());
    _setTestClient(makeFakeClient({ insertFails: true }), true);
  });

  afterEach(async () => {
    _setTestClient(null, false);
    await closeServer(server);
  });

  it("returns 500 with ok:false when the Supabase insert returns an error", async () => {
    const r = await post(url, "/api/discovery/community", VALID_BODY);
    assert.equal(r.status, 500, `expected 500 for insert failure, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.ok, false, "expected ok:false in error response");
  });

  it("includes a reason field in the 500 response body", async () => {
    const r = await post(url, "/api/discovery/community", VALID_BODY);
    assert.equal(r.status, 500, `expected 500 for insert failure, got ${r.status}`);
    assert.ok(
      typeof r.body.reason === "string" && r.body.reason.length > 0,
      `expected a non-empty reason string, got: ${JSON.stringify(r.body)}`,
    );
  });
});
